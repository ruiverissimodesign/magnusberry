<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class Attribute extends Model
{
    protected $table="attribute";
	protected $primaryKey = "ATTRIBUTE_ID";
	public $timestamps = false;
}
