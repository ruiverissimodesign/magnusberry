<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionLang extends Model
{
    protected $table = 'section_lang';
    protected $primaryKey = 'ID';
    protected $fillable = ['SECTION_ID', 'LANGUAGE_ID'];
    public $timestamps = false;
}
