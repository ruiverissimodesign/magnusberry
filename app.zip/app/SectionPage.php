<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed SECTION_ID
 * @property mixed PAGE_ID
 * @property mixed ORDER
 *
 * @method static firstOrCreate(array $array)
 */
class SectionPage extends Model
{
    protected $table = 'section_page';
    protected $primaryKey = 'ID';

    protected $fillable = ['PAGE_ID', 'SECTION_ID'];

    public $timestamps = false;
}
