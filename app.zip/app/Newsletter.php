<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class Newsletter extends Model
{
    protected $table="newsletter";
	protected $primaryKey = "ID";
	public $timestamps = false;
}
