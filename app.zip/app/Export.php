<?php
namespace App;

use App\Newsletter;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class Export implements FromQuery
{
    use Exportable;

    public function query()
    {
        return Newsletter::query();
    }
}
