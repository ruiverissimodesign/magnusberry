<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArticleFile extends Model
{
    protected $table = 'article_file';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['ARTICLE_ID', 'FILE_ID'];
}
