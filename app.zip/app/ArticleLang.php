<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArticleLang extends Model
{
    protected $table = 'article_lang';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['ARTICLE_ID', 'LANGUAGE_ID', "NAME_SEO", "TEXT_SEO"];
}
