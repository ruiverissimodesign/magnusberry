<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileLang extends Model
{
    protected $table="file_lang";
    protected $fillable = ['FILE_ID', 'LANGUAGE_ID'];
}
