<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionArticle extends Model
{
    protected $table = 'section_article';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['SECTION_ID', 'ARTICLE_ID'];
}
