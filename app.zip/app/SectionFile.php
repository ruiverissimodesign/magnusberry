<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionFile extends Model
{
    protected $table = 'section_file';
    protected $fillable = ['FILE_ID', 'SECTION_ID'];
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
