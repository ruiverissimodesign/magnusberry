<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class Product extends Model
{
    protected $table="product";
	protected $primaryKey = "PRODUCT_ID";
	public $timestamps = false;
}
