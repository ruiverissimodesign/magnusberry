<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BannerItemLang extends Model
{
    protected $table = 'e_banner_item_lang';
    protected $primaryKey = 'BANNER_ITEM_LANG_ID';
    public $timestamps = false;
}
