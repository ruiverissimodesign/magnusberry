<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class AttributeProduct extends Model
{
    protected $table="attribute_product";
	protected $primaryKey = "ATTRIBUTE_PRODUCT_ID";
	public $timestamps = false;
}
