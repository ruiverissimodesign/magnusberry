<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BannerItem extends Model
{
    protected $table = 'e_banner_item';
    protected $primaryKey = 'BANNER_ITEM_ID';
    public $timestamps = false;
}
