<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class AttributeName extends Model
{
    protected $table="attribute_name";
	protected $primaryKey = "ATTRIBUTE_NAME_LANG_ID";
	public $timestamps = false;
}
