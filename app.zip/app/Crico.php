<?php
namespace App;

use Illuminate\Http\Request;
use Auth;
use App;
use Session;
use App\Company;
use Mail;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;


class Crico{
    static function getMenuByURL($url) {
        $menu = DB::table("d_menu_lang")->where("URL",$url)->get();
        return $menu;
    }
    static function getMenuByParent($id, $lang = 1) {
        $menu = DB::table("d_menu_lang")
        ->join("d_menu","d_menu_lang.MENU_ID","=","d_menu.MENU_ID")
        ->where("d_menu_lang.LANGUAGE_ID","=",$lang)
        ->where("d_menu.PARENT_ID",$id)
        ->where("d_menu.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $menu;
    }
    static function getMenuById($id, $lang = 1, $status = 1) {


		if ($status) {
			$menu = DB::table("d_menu_lang")
			->join("d_menu","d_menu_lang.MENU_ID","=","d_menu.MENU_ID")
			->where("d_menu_lang.LANGUAGE_ID","=",$lang)
			->where("d_menu.MENU_ID",$id)
			->where("d_menu.STATUS","=","1")
			->orderBy("ORDER","ASC")
	        ->get();
		} else {
			$menu = DB::table("d_menu_lang")
			->join("d_menu","d_menu_lang.MENU_ID","=","d_menu.MENU_ID")
			->where("d_menu_lang.LANGUAGE_ID","=",$lang)
			->where("d_menu.MENU_ID",$id)
			->orderBy("ORDER","ASC")
			->get();
		}

        return $menu;
    }
    static function getArticleById($id, $lang = 1) {
        $article = DB::table("article_lang")
        ->join("article","article_lang.ARTICLE_ID","=","article.ARTICLE_ID")
        ->where("article_lang.LANGUAGE_ID","=",$lang)
        ->where("article.ARTICLE_ID",$id)
        ->where("article.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $article[0];
    }
    static function getProductCategoryById($id, $lang = 1) {
        $category = DB::table("product_category_lang")
        ->join("product_category","product_category_lang.C_PRODUCT_ID","=","product_category.C_PRODUCT_ID")
        ->where("product_category_lang.LANGUAGE_ID","=",$lang)
        ->where("product_category.C_PRODUCT_ID",$id)
        ->where("product_category.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $category[0];
    }
    static function getAllCategories($lang = 1) {
        $category = DB::table("product_category_lang")
        ->join("product_category","product_category_lang.C_PRODUCT_ID","=","product_category.C_PRODUCT_ID")
        ->where("product_category_lang.LANGUAGE_ID","=",$lang)
        ->where("product_category.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $category;
    }
    static function getMainCategories($lang = 1) {
        $category = DB::table("product_category_lang")
        ->join("product_category","product_category_lang.C_PRODUCT_ID","=","product_category.C_PRODUCT_ID")
        ->where("product_category_lang.LANGUAGE_ID","=",$lang)
        ->where("product_category.STATUS","=","1")
        ->where("product_category.C_PARENT_ID","-1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $category;
    }
    static function getProductCategoryChilds($id, $lang = 1) {
        $category = DB::table("product_category_lang")
        ->join("product_category","product_category_lang.C_PRODUCT_ID","=","product_category.C_PRODUCT_ID")
        ->where("product_category_lang.LANGUAGE_ID","=",$lang)
        ->where("product_category.C_PARENT_ID",$id)
        ->where("product_category.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $category;
    }
    static function getProductById($id, $lang = 1) {
        $product = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product.PRODUCT_ID",$id)
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->first();
        $attr = DB::table("attribute_product")
        ->join("attribute_name","attribute_name.ATTRIBUTE_ID","=","attribute_product.ATTRIBUTE_ID")
        ->join("attribute_value","attribute_value.ATTRIBUTE_VALUE_ID","=","attribute_product.ATTRIBUTE_VALUE_ID")
        ->where("attribute_name.LANGUAGE_ID","=",$lang)
        ->where("attribute_value.LANGUAGE_ID","=",$lang)
        ->where("attribute_product.PRODUCT_ID",$id)
        ->orderBy("attribute_product.ATTRIBUTE_PRODUCT_ID","DESC")
        ->get();
        if($attr->isNotEmpty()){
            $product->attributes = $attr;
        }

        return $product;
    }
    static function getProducts($id, $lang = 1) {
        $product = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product.PARENT_ID",$id)
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $product;
    }
    static function getHighlight($lang = 1) {
        $product = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product.DESTAQUE",1)
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $product;
    }
    static function getCatHighlight($cat,$lang = 1) {
        $product = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product.DESTAQUE",1)
        ->where("product.PARENT_ID",$cat)
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->get();

        return $product;
    }
    static function getCatCatHighlight($cat,$lang = 1) {
        $cats = DB::table("product_category")->where('C_PARENT_ID',$cat)->where('DESTAQUE',1)->get();
        $product = "";
        $products = [];
        foreach ($cats as $k => $c) {
            $product = DB::table("product_lang")
            ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
            ->where("product_lang.LANGUAGE_ID","=",$lang)
            ->where("product.DESTAQUE",1)
            ->where("product.PARENT_ID",$c->C_PRODUCT_ID)
            ->where("product.STATUS","=","1")
            ->orderBy("ORDER","ASC")
            ->get();
            array_push($products, $product);
        }
        foreach($products as $datas){foreach($datas as $data){$result[] = $data;}}
        return $result;
    }
    static function getProductsBySection($id, $lang = 1) {
        $section = DB::table("section_product")->where('SECTION_ID',$id)->get();
        $product = "";
        $products = [];
        foreach ($section as $k => $sec) {
            $product = DB::table("product_lang")
            ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
            ->where("product_lang.LANGUAGE_ID","=",$lang)
            ->where("product.PRODUCT_ID",$sec->PRODUCT_ID)
            ->where("product.STATUS","=","1")
            ->orderBy("ORDER","ASC")
            ->first();
            if(!empty($product)){
                $attr = DB::table("attribute_product")
                ->join("attribute_name","attribute_name.ATTRIBUTE_ID","=","attribute_product.ATTRIBUTE_ID")
                ->join("attribute_value","attribute_value.ATTRIBUTE_VALUE_ID","=","attribute_product.ATTRIBUTE_VALUE_ID")
                ->where("attribute_name.LANGUAGE_ID","=",$lang)
                ->where("attribute_value.LANGUAGE_ID","=",$lang)
                ->where("attribute_product.PRODUCT_ID",$sec->PRODUCT_ID)
                ->orderBy("attribute_product.ATTRIBUTE_PRODUCT_ID","DESC")
                ->get();
                if($attr->isNotEmpty()){
                    $product->attributes = $attr;
                }
                array_push($products, $product);
            }
        }

        return $products;
    }
    static function getProductsPage($id, $lang = 1 ,$page = 12) {
        $product = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product.PARENT_ID",$id)
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->paginate($page);

        return $product;
    }
    static function search($name, $lang = 1 ,$page = 12) {
        $search = DB::table("product_lang")
        ->join("product","product_lang.PRODUCT_ID","=","product.PRODUCT_ID")
        ->where("product_lang.LANGUAGE_ID","=",$lang)
        ->where("product_lang.NAME","LIKE","%{$name}%")
        ->where("product.STATUS","=","1")
        ->orderBy("ORDER","ASC")
        ->paginate($page);

        return $search;
    }
    static function getFile($id, $type, $code = null) {
        if($type == 'article'){
            if(!empty($code)){
                $article = DB::table("article_file")
                ->where("ARTICLE_ID","=",$id)
                ->where("CODE","LIKE","%{$code}%")
                ->get();
                $files = [];
                foreach ($article as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("article_file")->where("ARTICLE_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }else {
                $article = DB::table("article_file")
                ->where("ARTICLE_ID","=",$id)
                ->get();
                $files = [];
                foreach ($article as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("article_file")->where("ARTICLE_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }
        }elseif($type == 'section'){
            if(!empty($code)){
                $section = DB::table("section_file")
                ->where("SECTION_ID","=",$id)
                ->where("CODE","LIKE","%{$code}%")
                ->get();
                $files = [];
                foreach ($section as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("section_file")->where("SECTION_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }else {
                $section = DB::table("section_file")
                ->where("SECTION_ID","=",$id)
                ->get();
                $files = [];
                foreach ($section as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("section_file")->where("SECTION_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }
        }elseif($type == 'product'){
            if(!empty($code)){
                $product = DB::table("product_file")
                ->where("PRODUCT_ID","=",$id)
                ->where("CODE","LIKE","%{$code}%")
                ->get();
                $files = [];
                foreach ($product as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("product_file")->where("PRODUCT_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }else {
                $product = DB::table("product_file")
                ->where("PRODUCT_ID","=",$id)
                ->get();
                $files = [];
                foreach ($product as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("product_file")->where("PRODUCT_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }
        }elseif($type == 'category'){
            if(!empty($code)){
                $product = DB::table("product_category_file")
                ->where("C_PRODUCT_ID","=",$id)
                ->where("CODE","LIKE","%{$code}%")
                ->get();
                $files = [];
                foreach ($product as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("product_category_file")->where("C_PRODUCT_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }else{
                $product = DB::table("product_category_file")
                ->where("C_PRODUCT_ID","=",$id)
                ->get();
                $files = [];
                foreach ($product as $k => $file) {
                    $files[$k] = DB::table("files")
                    ->where("FILE_ID","=",$file->FILE_ID)
                    ->first();
                    $files[$k]->CODE = DB::table("product_category_file")->where("C_PRODUCT_ID","=",$id)->where("FILE_ID","=",$file->FILE_ID)->pluck('code')->first();
                }
                return $files;
            }
        }

    }
    static function addNewsletter($name = null, $email = null, $area = null) {
        if(DB::table("newsletter")->where("EMAIL",$email)->first()){
            return false;
        }else{
            $newsletter = DB::table("newsletter")->insert(["NAME" => $name, "EMAIL" => $email, "AREA" => $area, "STATUS" => 1]);
            return true;
        }

    }
    static function getSlideshowById($section, $foreachIndex, $limit = NULL, $orderby, $order, $menu) {
        $getBanner[$foreachIndex] = DB::table("e_banner")
        ->where("BANNER_ID",$section[$foreachIndex]->ITEMID)
        ->first();

        $countBanner[$foreachIndex] = DB::table("e_banner_item")
        ->where("BANNER_ID",$section[$foreachIndex]->ITEMID)
        ->limit($limit)
        ->orderBy($orderby,$order)
        ->get();

        $teamplateAssItem = "";

        foreach ($countBanner[$foreachIndex] as $b => $banner) {
            $getBanners[$foreachIndex][$b] = DB::table("e_banner_item")
            ->where("BANNER_ID",$banner->BANNER_ID)
            ->first();

            $getBannersLang[$foreachIndex][$b] = DB::table("e_banner_item_lang")
            ->where("BANNER_ITEM_ID",$getBanners[$foreachIndex][$b]->BANNER_ITEM_ID)
            ->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)
            ->first();

            $getBannerImg[$foreachIndex][$b] = DB::table("files")
            ->where("FILE_ID",$banner->IMG_ID)
            ->first();

            $teamplateAssItem .= view('frontend.teamplate.banner.item.'.$getBanner[$foreachIndex]->TEAMPLATE,
            [
                "banner_lang" => $getBannersLang[$foreachIndex][$b],
                "banner" => $getBanners[$foreachIndex][$b],
                "banner_img" => $getBannerImg[$foreachIndex][$b]
            ])->render();
        }

        $slideshow = view('frontend.teamplate.banner.'.$getBanner[$foreachIndex]
        ->TEAMPLATE, ["teamplate" => $teamplateAssItem])
        ->render();

        return $slideshow;
    }
    static function truncate($string, $length, $dots = "...") {
        return (strlen($string) > $length) ? substr($string, 0, $length - strlen($dots)) . $dots : $string;
    }
    static function dump($args = null){
      print "<!--\n";
  		var_dump($args);
  		print "\n-->";
    }
    static function config($pluck = null){
      return Company::pluck($pluck)[0];
    }

}
