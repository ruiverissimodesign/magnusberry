<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageMenu extends Model
{
    protected $table = 'page_menu';
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
