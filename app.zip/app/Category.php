<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class Category extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'CATEGORY_ID';
    public $timestamps = false;
    protected $fillable = ['NAME', 'PARENT_ID'];
    
    public function getChildsAttribute(){
        return Category::where('PARENT_ID',$this->CATEGORY_ID )->get();
    }
}
