<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $table = 'e_banner';
    protected $primaryKey = 'BANNER_ID';
    public $timestamps = false;
}
