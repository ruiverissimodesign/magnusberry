<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Rank extends Model
{
    protected $table = 'rank_permissions';
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
