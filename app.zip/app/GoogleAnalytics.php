<?php
namespace App;

use Analytics;
use Spatie\Analytics\Period;

class GoogleAnalytics{

    static function topCountries() {
        $country = Analytics::performQuery(Period::days(30),'ga:sessions',  ['dimensions'=>'ga:country','sort'=>'-ga:sessions']);
        $result= collect($country['rows'] ?? [])->map(function (array $dateRow) {
            return [$dateRow[0],(int) $dateRow[1]];
        });
        return $result;
    }
    static function totalVisits() {
        $country = Analytics::performQuery(Period::days(30),'ga:users');
        $result= collect($country['rows'] ?? [])->map(function (array $dateRow) {
            return [$dateRow[0]];
        });
        return $result;
    }
    static function allVisitors() {
        $country = Analytics::performQuery(Period::days(30),'ga:sessions',  ['dimensions'=>'ga:date','metrics'=>'ga:visitors']);
        $result= collect($country['rows'] ?? [])->map(function (array $dateRow) {
            return [ date("Y-m-d",strtotime($dateRow[0])),(int) $dateRow[1]];
        });
        return $result;
    }
    static function liveUsers() {
        $live_users = Analytics::getAnalyticsService()->data_realtime->get('ga:'.env('ANALYTICS_VIEW_ID'), 'rt:activeVisitors')->totalsForAllResults['rt:activeVisitors'];
        return $live_users;
    }
    static function device() {
        $country = Analytics::performQuery(Period::days(30),'ga:sessions',  ['dimensions'=>'ga:deviceCategory','metrics'=>'ga:users']);
        $result= collect($country['rows'] ?? [])->map(function (array $dateRow) {
            return [ucfirst($dateRow[0]), (int) $dateRow[1]];
        });
        return $result;
    }

}
