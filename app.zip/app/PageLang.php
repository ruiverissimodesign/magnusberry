<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageLang extends Model
{
    protected $table = 'page_lang';
    protected $primaryKey = 'ID';
    public $timestamps = false;
}
