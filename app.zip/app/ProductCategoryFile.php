<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategoryFile extends Model
{
    protected $table = 'product_category_file';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['C_PARENT_ID', 'FILE_ID'];
}
