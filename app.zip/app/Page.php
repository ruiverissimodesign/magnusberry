<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static findOrFail(int $id)
 */
class Page extends Model
{
    protected $table = 'page';
    protected $primaryKey = 'PAGE_ID';
    public $timestamps = true;
}
