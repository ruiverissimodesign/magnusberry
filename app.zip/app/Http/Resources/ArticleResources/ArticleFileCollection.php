<?php

namespace App\Http\Resources\ArticleResources;

use Illuminate\Http\Resources\Json\ResourceCollection;
class ArticleFileCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {


        return $this->collection->map(function($article_files) {
            return ArticleFileResource::make($article_files)->withLanguage($this->selectedLanguage);
        });
    }
}
