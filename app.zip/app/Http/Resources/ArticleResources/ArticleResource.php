<?php

namespace App\Http\Resources\ArticleResources;

use App\ArticleLang;
use App\Languages;
use Illuminate\Http\Resources\Json\JsonResource;

use App\ArticleFile;
class ArticleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */

    protected $selectedLanguage;


    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {

        $files = ArticleFileCollection::make(
            ArticleFile::where('ARTICLE_ID', $this->ARTICLE_ID)->get()
        )->withLanguage(
            $this->selectedLanguage
        );
        try{
            $traductions = ArticleLang::where(
                [
                    'ARTICLE_ID'=> $this->ARTICLE_ID,
                    'LANGUAGE_ID'=> Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID
                ])
                ->first();
        }catch (\Exception $e){
            return [
                'ERROR'=> 404,
                'MESSAGE' => "Language doesn't exist"
            ];
        }

        // The name is required
        try{
            $name = $traductions->NAME_SEO;

        }catch(\Exception $e){
            return [
                'ERROR' => "Language " . $this->selectedLanguage . " active, but this article has no traduction",
                'CODE' => 400,
            ];
        }


        return [
            'NAME' => $name,
            'text' => $traductions->TEXT_SEO ?? null,
            'AUTHOR' => $this->AUTHOR,
            'CATEGORY' => $this->CATEGORY,
            'DESTAQUE' => $this->DESTAQUE,
            'ORDER' => $this->ORDER,
            'CUSTOMCAMPS' => $this->CUSTOMCAMPS,
            'CREATED_AT' => $this->created_at,
            'files' => $files
            ];
    }
}
