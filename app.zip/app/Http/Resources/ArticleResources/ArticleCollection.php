<?php

namespace App\Http\Resources\ArticleResources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class ArticleCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {
        $articles = [];
        foreach($this->collection as $article){
            if($article->STATUS == "0") continue;
            $articles[] =  ArticleResource::make($article)->withLanguage($this->selectedLanguage);
        }
        return $articles;
    }
}
