<?php

namespace App\Http\Resources\ArticleResources;

use App\File;
use App\Http\Resources\FileResources\FileResource;
use Illuminate\Http\Resources\Json\JsonResource;
class ArticleFileResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {

        $fileToSearch = File::findOrFail($this->FILE_ID);

        $file = FileResource::make($fileToSearch)->withLanguage($this->selectedLanguage);
        $file->resource->setAttribute('CODE', $this->CODE);

        return $file;
    }
}
