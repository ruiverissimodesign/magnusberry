<?php

namespace App\Http\Resources\SectionResources;

use App\Article;
use App\Banner;
use App\Category;
use App\Http\Resources\ArticleResources\ArticleCollection;
use App\Http\Resources\ArticleResources\ArticleResource;
use App\Http\Resources\BannerResources\BannerResource;
use App\Http\Resources\CategoryResources\CategoryResource;
use App\Languages;
use App\SectionArticle;
use App\SectionFile;
use App\SectionLang;
use Illuminate\Http\Resources\Json\JsonResource;
use mysql_xdevapi\Exception;

class SectionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang)
    {
        $this->selectedLanguage = $lang;
        return $this;
    }



    public function toArray($request)
    {
        //Files Handler

        $files = SectionFileCollection::make(
            SectionFile::where('SECTION_ID', $this->SECTION_ID)->get()
        )->withLanguage(
            $this->selectedLanguage
        );

        // Switch Between type cases
        $item_data = null;
        switch ($this->TYPE) {
            case 'article':
                $article = Article::find($this->ITEMID);
                if($article->STATUS == '0'){
                    break;
                }
                $item_data = $article ? ArticleResource::make($article)->withLanguage($this->selectedLanguage) : ['error' => 'Article Not Found', 'code' => 404];
                break;
            case 'grouparticles':
                $articles_id = SectionArticle::where([
                    'SECTION_ID'=> $this->SECTION_ID,
                ])->pluck('ARTICLE_ID');
                $articles = Article::find($articles_id);
                $item_data = ArticleCollection::make($articles)->withLanguage($this->selectedLanguage);
                break;

            case 'slideshow':
                $slideshow = Banner::find($this->ITEMID);
                $item_data = $slideshow ? BannerResource::make($slideshow)->withLanguage($this->selectedLanguage) : ['error' => 'Slideshow Not Found', 'code' => 404];
                break;
            case 'categories':
                $category = Category::find($this->ITEMID);
                $item_data = $category ? CategoryResource::make($category)->withLanguage($this->selectedLanguage) : ['error' => 'Slideshow Not Found', 'code' => 404];
                break;
            case 'section':
            default:
                $item_data = null;
        }

        try{
            $traductions = SectionLang::where([
                'SECTION_ID' => $this->SECTION_ID,
                'LANGUAGE_ID' => Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID,
            ])->first();
        }catch(\Exception $e){
            return [
                'ERROR'=> 404,
                'MESSAGE' => "Language doesn't exists"
            ];
        }
        try{
            $name = $traductions->NAME_SEO;

        }catch(\Exception $e){
            return [
                'ERROR' => "Language " . $this->selectedLanguage . " active, but this section has no traduction",
                'CODE' => 400,
            ];
        }


        return [
            'NAME' => $name,
            'TYPE' => $this->TYPE,
            'ITEM_ID' => $this->ITEMID,
            'ITEM_DATA' => $item_data,
            'TEXT' => $traductions->TEXT_SEO ?? null,
            'ORDER' => $this->ORDER ?? null, // This is attributed is only added in page resource (SectionPageResource)
            'ORDER_BY' => $this->ORDERBY,
            'LIMIT' => $this->LIMIT,
            'DESTAQUE' => $this->DESTAQUE,
            'CUSTOM_CAMPS' => $this->CUSTOM_CAMPS,
            'FILES' => $files,
        ];


    }
}
