<?php

namespace App\Http\Resources\SectionResources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class SectionCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {
        $articles = [];
        foreach($this->collection as $section){
            dd($section);
            $articles[] =  SectionResource::make($section)->withLanguage($this->selectedLanguage);
        }
        return $articles;
    }
}
