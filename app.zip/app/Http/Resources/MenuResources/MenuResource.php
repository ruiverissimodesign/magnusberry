<?php

namespace App\Http\Resources\MenuResources;

use App\Languages;
use App\Menu;
use App\MenuLang;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Resources\Json\JsonResource;

class MenuResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {


        //- ------------------- -

        // This code tries to get and assign to menuLang the traductions for the menu
        // If it fail, a jsno with a error message is returned
        try {
            $traductions = MenuLang::where([
                'MENU_ID'=> $this->MENU_ID,
                'LANGUAGE_ID' => Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID
            ])->first();
        } catch (\Exception  $th) {
            return [
                'error' => "Language doesn't exist",
                'code' => 404
            ];
        }
        try{
            $name = $traductions->M_NAME;
            $url = $traductions->URL;
        }catch (\Exception $e){
            return [
                'ERROR' => "Language " . $this->selectedLanguage . " active, but this menu has no traduction",
                'CODE' => 400,
            ];
        }

        //This code checks if current menu has childs menus
        $subMenus = Menu::where('PARENT_ID', $this->MENU_ID)->orderBy('ORDER')->get();


        // if it have childs menus, then we call the MenuResource to get the submenu and recursivly the submenus of that submenu
        // This acts like a recursive function
        // When all submenus are done, it will return all to this child variable
        $child = [];
        if($subMenus){
            foreach ($subMenus as $subMenu) {
                if($subMenu->STATUS === "0"){
                    continue;
                }
                $subMenuData = self::make($subMenu)->withLanguage($this->selectedLanguage);


                $child[] = $subMenuData;
            }
        }



        // then we return the data we want
        // this data can be changed tho
        // data from menuLang is data has been traduced
        return [
            'MENU_NAME' => $name,
            'URL' => $url,
            'PAGE_ID' => $this->PAGE_ID,
            'TITLE' => $traductions->TITLE_SEO ?? null,
            'DESCRIPTION' => $traductions->DESCRIPTION_SEO ?? null,
            'KEYWORDS' => $traductions->KEYWORDS_SEO ?? null,
            'MENU_CHILDS' => $child,
            'STATUS' => $this->STATUS,
            'ORDER' => $this->ORDER,
        ];
    }
}
