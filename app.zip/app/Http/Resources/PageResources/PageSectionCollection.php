<?php

namespace App\Http\Resources\PageResources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class PageSectionCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang)
    {
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {
        return $this->collection->map(function($page_section) {

            return PageSectionResource::make($page_section)->withLanguage($this->selectedLanguage);
        });
    }
}
