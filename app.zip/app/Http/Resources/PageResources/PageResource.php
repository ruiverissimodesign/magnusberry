<?php

namespace App\Http\Resources\PageResources;

use App\Http\Resources\SectionResources\SectionCollection;
use App\Languages;
use App\PageLang;
use App\Section;
use App\SectionPage;
use Illuminate\Http\Resources\Json\JsonResource;

class PageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang)
    {
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {
        try{
            $traductions = PageLang::where([
                'PAGE_ID' => $this->PAGE_ID,
                'LANGUAGE_ID' => Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID
            ])->first();
        }catch (\Exception $e){
            return [
                'ERROR'=> 404,
                'MESSAGE' => "Language doesn't exists"
            ];
        }
        try{
            $name = $traductions->NAME_SEO;

        }catch(\Exception $e){
            return [
                'ERROR' => "Language " . $this->selectedLanguage . " active, but this page has no traduction",
                'CODE' => 400,
            ];
        }

        $sections_data = PageSectionCollection::make(SectionPage::where('PAGE_ID', $this->PAGE_ID)->get())->withLanguage($this->selectedLanguage);
        return [
            'NAME' => $name,
            'SECTIONS_DATA' => $sections_data
        ];
    }
}
