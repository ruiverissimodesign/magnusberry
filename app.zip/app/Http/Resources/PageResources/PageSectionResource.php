<?php

namespace App\Http\Resources\PageResources;

use App\Http\Resources\SectionResources\SectionCollection;
use App\Http\Resources\SectionResources\SectionResource;
use App\Section;
use App\SectionPage;
use Illuminate\Http\Resources\Json\JsonResource;

class PageSectionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang)
    {
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {

        $section_ToSearch = Section::findOrFail($this->SECTION_ID);
        $section = SectionResource::make($section_ToSearch)->withLanguage($this->selectedLanguage);
        $section->resource->setAttribute('ORDER', $this->ORDER);

        return $section;
    }
}
