<?php

namespace App\Http\Resources\CompanyResources;

use Illuminate\Http\Resources\Json\JsonResource;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'NAME' => $this->NAME ?? null,
            'LOGO' => $this->LOGO ?? null,
            'LOGO_ALTERNATIVE' => $this->LOGO_ALTERNATIVE ?? null,
            'FAVICON' => $this->FAVICON ?? null,
            'LOGOPRINT' => $this->LOGOPRINT ?? null,
            'NIF' => $this->NIF ?? null,
            'ADDRESS' => $this->ADDRESS ?? null,
            'POSTCODE' => $this->POSTCODE ?? null,
            'CITY' => $this->CITY ?? null,
            'COUNTRY' => $this->COUNTRY ?? null,
            'PHONE' => $this->PHONE ?? null,
            'MOBILE' => $this->MOBILE ?? null,
            'EMAIL' => $this->EMAIL ?? null,
            'MAP' => $this->MAP ?? null,
            'LATITUDE' => $this->LATITUDE ?? null,
            'LONGITUDE' => $this->LONGITUDE ?? null,


        ];
    }

}
