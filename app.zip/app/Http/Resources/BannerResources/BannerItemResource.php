<?php

namespace App\Http\Resources\BannerResources;

use App\BannerItemLang;
use App\File;
use App\Http\Resources\FileResources\FileResource;
use App\Languages;
use Illuminate\Http\Resources\Json\JsonResource;

class BannerItemResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */

    protected $selectedLanguage;


    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {
        try{
            $traductions = BannerItemLang::where([
                'BANNER_ITEM_ID' => $this->BANNER_ITEM_ID,
                'LANGUAGE_ID' => Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID
            ])->first();
        }catch (\Exception $e){
            return [
                'ERROR'=> 404,
                'MESSAGE' => "Language doesn't exists"
            ];
        }


        return [
            'TITLE' => $traductions->TITLE ?? null,
            'SUBTITLE' => $traductions->SUBTITLE ?? null,
            'LINK_NAME' => $traductions->LINK_NAME ?? null,
            'LINK' => $traductions->LINK ?? null,
            'BANNER_IMAGE' => FileResource::make(File::where('FILE_ID', $this->IMG_ID)->first())->withLanguage($this->selectedLanguage),


        ];
    }
}
