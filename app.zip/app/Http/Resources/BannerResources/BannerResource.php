<?php

namespace App\Http\Resources\BannerResources;

use App\BannerItem;
use Illuminate\Http\Resources\Json\JsonResource;

class BannerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */

    protected $selectedLanguage;


    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {


        return [
            'BANNER_ID' => $this->BANNER_ID,
            'NAME' => $this->NAME,
            'BANNER_ITEMS' => BannerItemCollection::make(BannerItem::where('BANNER_ID', $this->BANNER_ID)->get())->withLanguage($this->selectedLanguage)
        ];
    }
}
