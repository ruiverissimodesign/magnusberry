<?php

namespace App\Http\Resources\BannerResources;

use App\File;
use App\Http\Resources\FileResources\FileResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class BannerItemCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  Request  $request
     * @return array
     */

    protected $selectedLanguage;


    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }
    public function toArray($request)
    {
        return $this->collection->map(function($banner_item) {

            return BannerItemResource::make($banner_item)->withLanguage($this->selectedLanguage);
        });
    }


}
