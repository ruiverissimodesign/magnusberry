<?php

namespace App\Http\Resources\FileResources;

use App\FileLang;
use App\Languages;
use Illuminate\Http\Resources\Json\JsonResource;

class FileResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected $selectedLanguage;

    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {



            // dd([$this->FILE_ID, $languageId]);
        try{
            $traduction = FileLang::where([
                'FILE_ID'=> $this->FILE_ID,
                'LANGUAGE_ID' => Languages::where('SLUG', $this->selectedLanguage)->first()->LANGUAGE_ID
            ])->first();
        }catch (\Exception $e){
            return [
                'ERROR'=> 404,
                'MESSAGE' => "Language doesn't exist"
            ];
        }



        return [
            "FILE"=> $this->FILE,
            "ISIMAGE"=> $this->ISIMAGE === "1" ? true : false,
            "TYPE" => $this->TYPE,
            "IMAGENAME"=> $this->IMAGENAME,
            "DESCRIPTION" => $traduction->DESCRIPTION ?? null,
            "CODE" => $this->CODE ? $this->CODE : null
        ];
    }
}
