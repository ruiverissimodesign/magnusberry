<?php

namespace App\Http\Resources\CategoryResources;

use App\Http\Resources\ArticleResources\ArticleCollection;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Article;
class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array
     */

    protected $selectedLanguage;


    public function withLanguage($lang){
        $this->selectedLanguage = $lang;
        return $this;
    }

    public function toArray($request)
    {
        return [
            'NAME' => $this->NAME,
            'STATUS' => $this->STATUS,
            'ARTICLES' => ArticleCollection::make(Article::where(
                [
                    'CATEGORY' => $this->CATEGORY_ID,
                    'STATUS'=> 1
                ]
            )->orderBy('ORDER')->get())->withLanguage($this->selectedLanguage),

        ];
    }
}
