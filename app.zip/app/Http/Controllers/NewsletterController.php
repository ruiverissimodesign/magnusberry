<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Excel;
use App\Export;

class NewsletterController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.newsletter.';
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
	public function index() {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Newsletter')->pluck('PERMISSIONS')[0] == "1"){
            $newsletter = DB::table("newsletter")->orderBy("id","ASC")->get();

            return view($this->prefixViewDirFiles . 'list',compact("newsletter"));
        }else{
          return redirect()->route('home');
        }
	}
	public function export() {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Newsletter')->pluck('PERMISSIONS')[0] == "1"){
            $date = date("Ymd");
            return Excel::download(new Export, 'Newsletter_'.$date.'.csv');
            echo "<script>window.close();</script>";
        }
	}
}
