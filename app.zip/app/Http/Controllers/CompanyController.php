<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Rank;
use Auth;
use App\Company;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function __construct()
     {
         $this->middleware('auth');
         $this->prefixViewDir = 'backoffice.company.';
     }

    public function index()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Company')->pluck('PERMISSIONS')[0] == "1"){
        return redirect()->route('company.create');
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Company')->pluck('PERMISSIONS')[0] == "1"){
        $company = Company::first();
        if($company){
            return view($this->prefixViewDir . 'edit')->with('company', $company);
        }{
            return view($this->prefixViewDir . 'company');
        }
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Company')->pluck('PERMISSIONS')[0] == "1"){
        $request->validate([
            'CompanyName' => 'required|string|max:50',
            'CompanyNIF' => 'nullable|integer|digits:9',
            'CompanyAddress' => 'nullable|string',
            'CompanyPostcode' => 'nullable|regex:^\\d{4}[-]{0,1}\\d{3}$^',
            'CompanyCity' => 'nullable|string|max:50',
            'CompanyCountry' => 'nullable|string|max:50',
            'CompanyPhone' => 'nullable|integer|digits:9',
            'CompanyMobile' => 'nullable|integer|digits:9',
            'CompanyEmail' => 'nullable|email',
            'CompanyMap' => 'nullable',
            'CompanyLatitude' => 'nullable|alpha_num',
            'CompanyLongitude' => 'nullable|alpha_num',
            'CompanyLogo' => 'nullable|image',
            'CompanyAlternativeLogo' => 'nullable|image',
            'CompanyLogoPrint' => 'nullable|image',
            'CompanyOrcamento' => 'nullable|image',
            'CompanyKipOrcamento' => 'nullable|image',
            'CompanyKipContact' => 'nullable|image',
            'CompanyFavicon' => 'nullable|image',
        ]);
        $company = new Company;
        $company = $this->data($request, $company);
        $logo_file = $request->CompanyLogo;
        $logo_alternative_file = $request->CompanyAlternativeLogo;
        $logo_print_file = $request->CompanyLogoPrint;
        $logo_orcamento = $request->CompanyOrcamento;
        $logo_Kiporcamento = $request->CompanyKipOrcamento;
        $logo_kipcontact = $request->CompanyKipContact;
        $favicon_file = $request->CompanyFavicon;






        if(!empty($logo_file) && isset($logo_file)){

            $logo_naming = $logo_file->getClientOriginalName();
            $logo_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_naming, PATHINFO_FILENAME)))));
            $logo_naming = $logo_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_file->getClientOriginalExtension();

            Storage::put("company/".$logo_naming, fopen($logo_file, 'r+'));
            $company->LOGO = $logo_naming;
        }

        if(!empty($logo_alternative_file) && isset($logo_alternative_file)){
            $logo_alternative_naming = $logo_alternative_file->getClientOriginalName();
            $logo_alternative_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_alternative_naming, PATHINFO_FILENAME)))));
            $logo_alternative_naming = $logo_alternative_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_alternative_file->getClientOriginalExtension();

            Storage::put("company/".$logo_alternative_naming, fopen($logo_alternative_file, 'r+'));
            $company->LOGO_ALTERNATIVE = $logo_alternative_naming;
        }

        if(!empty($logo_print_file) && isset($logo_print_file)){
            $logo_print_naming = $logo_print_file->getClientOriginalName();
            $logo_print_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_print_naming, PATHINFO_FILENAME)))));
            $logo_print_naming = $logo_print_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_print_file->getClientOriginalExtension();
            Storage::put("company/".$logo_print_naming, fopen($logo_print_file, 'r+'));
            $company->LOGOPRINT = $logo_print_naming;
        }
        if(!empty($logo_orcamento) && isset($logo_orcamento)){
            $logo_orcamento_naming = $logo_orcamento->getClientOriginalName();
            $logo_orcamento_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_orcamento_naming, PATHINFO_FILENAME)))));
            $logo_orcamento_naming = $logo_orcamento_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_orcamento->getClientOriginalExtension();
            Storage::put("company/".$logo_orcamento_naming, fopen($logo_orcamento, 'r+'));
            $company->ORCAMENTO = $logo_orcamento_naming;
        }
        if(!empty($logo_Kiporcamento) && isset($logo_Kiporcamento)){
            $logo_orcamento_naming_kip = $logo_Kiporcamento->getClientOriginalName();
            $logo_orcamento_naming_kip = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_orcamento_naming_kip, PATHINFO_FILENAME)))));
            $logo_orcamento_naming_kip = $logo_orcamento_naming_kip.'_'.date("Y-m-d-H-i-s").'.'.$logo_Kiporcamento->getClientOriginalExtension();
            Storage::put("company/".$logo_orcamento_naming_kip, fopen($logo_Kiporcamento, 'r+'));
            $company->KIPORCAMENTO = $logo_orcamento_naming_kip;
        }
        if(!empty($logo_kipcontact) && isset($logo_kipcontact)){
            $logo_contact_naming_kip = $logo_kipcontact->getClientOriginalName();
            $logo_contact_naming_kip = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_contact_naming_kip, PATHINFO_FILENAME)))));
            $logo_contact_naming_kip = $logo_orcamento_naming_kip.'_'.date("Y-m-d-H-i-s").'.'.$logo_kipcontact->getClientOriginalExtension();
            Storage::put("company/".$logo_contact_naming_kip, fopen($logo_kipcontact, 'r+'));
            $company->KIPCONTACT = $logo_contact_naming_kip;
        }

        if(!empty($favicon_file) && isset($favicon_file)){
            $favicon_naming = $favicon_file->getClientOriginalName();
            $favicon_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($favicon_naming, PATHINFO_FILENAME)))));
            $favicon_naming = $favicon_naming.'_'.date("Y-m-d-H-i-s").'.'.$favicon_file->getClientOriginalExtension();
            Storage::put("company/".$favicon_naming, fopen($favicon_file, 'r+'));
            $company->FAVICON = $favicon_naming;
        }

        $company->save();

        return redirect()->route('company.create');
      }else{
        return redirect()->route('home');
      }
    }
    public function update (Request $request) {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Company')->pluck('PERMISSIONS')[0] == "1"){
        $company = Company::first();
        $company = $this->data($request, $company);

        $logo_file = $request->CompanyLogo;
        $logo_alternative_file = $request->CompanyAlternativeLogo;
        $logo_print_file = $request->CompanyLogoPrint;
        $logo_orcamento = $request->CompanyOrcamento;
        $favicon_file = $request->CompanyFavicon;
        $logo_Kiporcamento = $request->CompanyKipOrcamento;
        $logo_kipcontact = $request->CompanyKipContact;

        $validator = $request->validate([
            'CompanyName' => 'required|string|max:50',
            'CompanyNIF' => 'nullable|integer|digits:9',
            'CompanyAddress' => 'nullable|string',
            'CompanyPostcode' => 'nullable|regex:^\\d{4}[-]{0,1}\\d{3}$^',
            'CompanyCity' => 'nullable|string|max:50',
            'CompanyCountry' => 'nullable|string|max:50',
            'CompanyPhone' => 'nullable|integer|digits:9',
            'CompanyMobile' => 'nullable|integer|digits:9',
            'CompanyEmail' => 'nullable|email',
            'CompanyMap' => 'nullable',
            'CompanyLatitude' => 'nullable',
            'CompanyLongitude' => 'nullable',
            'Facebook' => 'nullable|string',
            'Instagram' => 'nullable|string',
            'Linkedin' => 'nullable|string',
            'Pinterest' => 'nullable|string',
            'Facebook_kip' => 'nullable|string',
            'Instagram_kip' => 'nullable|string',
            'Linkedin_kip' => 'nullable|string',
            'Pinterest_kip' => 'nullable|string',
            'CompanyLogo' => 'nullable|image',
            'CompanyAlternativeLogo' => 'nullable|image',
            'CompanyLogoPrint' => 'nullable|image',
            'CompanyOrcamento' => 'nullable|image',
            'CompanyKipOrcamento' => 'nullable|image',
            'CompanyKipContact' => 'nullable|image',
            'CompanyFavicon' => 'nullable|image',
        ]);

        // if ($validator->fails()) {
        //     $form_status = false;
        //     return redirect()->route('company.create')->withErrors($validator);
        // }else{
        //     $form_status = true;
        // }


        if(!empty($logo_file) && isset($logo_file)){
            $logo_naming = $logo_file->getClientOriginalName();
            $logo_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_naming, PATHINFO_FILENAME)))));
            $logo_naming = $logo_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_file->getClientOriginalExtension();

            Storage::put("company/".$logo_naming, fopen($logo_file, 'r+'));
            $company->LOGO = $logo_naming;
        }

        if(!empty($logo_alternative_file) && isset($logo_alternative_file)){
            $logo_alternative_naming = $logo_alternative_file->getClientOriginalName();
            $logo_alternative_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_alternative_naming, PATHINFO_FILENAME)))));
            $logo_alternative_naming = $logo_alternative_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_alternative_file->getClientOriginalExtension();

            Storage::put("company/".$logo_alternative_naming, fopen($logo_alternative_file, 'r+'));
            $company->LOGO_ALTERNATIVE = $logo_alternative_naming;
        }

        if(!empty($logo_print_file) && isset($logo_print_file)){
            $logo_print_naming = $logo_print_file->getClientOriginalName();
            $logo_print_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_print_naming, PATHINFO_FILENAME)))));
            $logo_print_naming = $logo_print_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_print_file->getClientOriginalExtension();
            Storage::put("company/".$logo_print_naming, fopen($logo_print_file, 'r+'));
            $company->LOGOPRINT = $logo_print_naming;
        }
        if(!empty($logo_orcamento) && isset($logo_orcamento)){
            $logo_orcamento_naming = $logo_orcamento->getClientOriginalName();
            $logo_orcamento_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_orcamento_naming, PATHINFO_FILENAME)))));
            $logo_orcamento_naming = $logo_orcamento_naming.'_'.date("Y-m-d-H-i-s").'.'.$logo_orcamento->getClientOriginalExtension();
            Storage::put("company/".$logo_orcamento_naming, fopen($logo_orcamento, 'r+'));
            $company->ORCAMENTO = $logo_orcamento_naming;
        }
        if(!empty($logo_Kiporcamento) && isset($logo_Kiporcamento)){
            $logo_orcamento_naming_kip = $logo_Kiporcamento->getClientOriginalName();
            $logo_orcamento_naming_kip = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_orcamento_naming_kip, PATHINFO_FILENAME)))));
            $logo_orcamento_naming_kip = $logo_orcamento_naming_kip.'_'.date("Y-m-d-H-i-s").'.'.$logo_Kiporcamento->getClientOriginalExtension();
            Storage::put("company/".$logo_orcamento_naming_kip, fopen($logo_Kiporcamento, 'r+'));
            $company->KIPORCAMENTO = $logo_orcamento_naming_kip;
        }
        if(!empty($logo_kipcontact) && isset($logo_kipcontact)){
            $logo_contact_naming_kip = $logo_kipcontact->getClientOriginalName();
            $logo_contact_naming_kip = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($logo_contact_naming_kip, PATHINFO_FILENAME)))));
            $logo_contact_naming_kip = $logo_orcamento_naming_kip.'_'.date("Y-m-d-H-i-s").'.'.$logo_kipcontact->getClientOriginalExtension();
            Storage::put("company/".$logo_contact_naming_kip, fopen($logo_kipcontact, 'r+'));
            $company->KIPCONTACT = $logo_contact_naming_kip;
        }
        if(!empty($favicon_file) && isset($favicon_file)){
            $favicon_naming = $favicon_file->getClientOriginalName();
            $favicon_naming = preg_replace("/[\s_]/", "-", preg_replace("/[\s-]+/", " ", preg_replace("/[^a-z0-9_\s-]/", "", strtolower(pathinfo($favicon_naming, PATHINFO_FILENAME)))));
            $favicon_naming = $favicon_naming.'_'.date("Y-m-d-H-i-s").'.'.$favicon_file->getClientOriginalExtension();
            Storage::put("company/".$favicon_naming, fopen($favicon_file, 'r+'));
            $company->FAVICON = $favicon_naming;
        }

        $company->save();
        return redirect()->route('company.create');
      }else{
        return redirect()->route('home');
      }
    }

    private function data (Request $request, $company) {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Company')->pluck('PERMISSIONS')[0] == "1"){
        $company->NAME = $request->input('CompanyName');
        $company->NIF = $request->input('CompanyNIF');
        $company->ADDRESS = $request->input('CompanyAddress');
        $company->POSTCODE = $request->input('CompanyPostcode');
        $company->CITY = $request->input('CompanyCity');
        $company->COUNTRY = $request->input('CompanyCountry');
        $company->PHONE = $request->input('CompanyPhone');
        $company->MOBILE = $request->input('CompanyMobile');
        $company->EMAIL = $request->input('CompanyEmail');
        $company->MAP = $request->input('CompanyMap');
        $company->LATITUDE = $request->input('CompanyLatitude');
        $company->LONGITUDE = $request->input('CompanyLongitude');
        $company->FACEBOOK = $request->input('Facebook');
        $company->INSTAGRAM = $request->input('Instagram');
        $company->LINKEDIN = $request->input('Linkedin');
        $company->PINTEREST = $request->input('Pinterest');
        $company->FACEBOOK_KIP = $request->input('Facebook_kip');
        $company->INSTAGRAM_KIP = $request->input('Instagram_kip');
        $company->LINKEDIN_KIP = $request->input('Linkedin_kip');
        $company->PINTEREST_KIP = $request->input('Pinterest_kip');

        return $company;
      }else{
        return redirect()->route('home');
      }
    }



}
