<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Article;
use App\Section;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;
use App\Rank;
use Auth;


class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDir = '';
    protected $initialCategories;
    protected $globalDataArray;
    protected $spacerCount;
    public function __construct(){
        $this->middleware('auth');
        $this->prefixViewDir = 'backoffice.category.';
    }

    public function listOfChildsByParent($id = -1)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListCat')->pluck('PERMISSIONS')[0] == "1"){
        if((int) $id === 0){
            abort(404);
        }

        $categories = Category::where('PARENT_ID', $id)->get();
        $allCategories = Category::all();
        $getParent = DB::table('categories')->where('CATEGORY_ID','=', $id)->get();
        $idCrumb = $id;
        $crumb = TRUE;
        $crumbArray = [];
        $saves_ids = [];
        while ($crumb == TRUE) {
            if ($idCrumb != -1 ) {
                $getParent2 = DB::table('categories')->where('CATEGORY_ID','=', $idCrumb)->get();
                array_push($saves_ids, $idCrumb);
                $idCrumb = $getParent2[0]->PARENT_ID;

            }else{
                $crumb == FALSE;
                break;
            }
        }
        if (!empty($saves_ids)) {
            foreach ($saves_ids as $key => $sid) {
                $menubreadcrumb = DB::table('categories')->where('CATEGORY_ID','=', $sid)->get();
                array_push($crumbArray, $menubreadcrumb);

            }
        }
        $crumbArray = array_reverse($crumbArray);
        // dd($crumbArray);

        return view($this->prefixViewDir . 'index', compact('categories', 'allCategories'))->with('breadcrumb', $crumbArray)->with('pgId', $id)->with('parentId', $getParent);
      }else{
        return redirect()->route('home');
      }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddCat')->pluck('PERMISSIONS')[0] == "1"){
        $categories = Category::where('PARENT_ID', -1)->get();
        return view($this->prefixViewDir . 'create', compact('categories'));
      }else{
        return redirect()->route('home');
      }

    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddCat')->pluck('PERMISSIONS')[0] == "1"){
        $request->validate([
            'NAME' => 'required|min:3|max:50|unique:categories',
        ],
        [
            'required' => Lang::get('system.edit-error-name-required'),
            'min' => Lang::get('system.edit-error-name-min'),
            'max' => Lang::get('system.edit-error-name-max'),

        ]);



        $category = new Category();
        $category->PARENT_ID = $request->input('category');
        $category->NAME = $request->input('NAME');
        $category->STATUS = $request->input('status') == 'on' ? 1 : 0;
        $category->save();
        $request->session()->flash('alert-success', Lang::get('system.created-category-success'));

        return redirect()->route('category.index');

      }else{
        return redirect()->route('home');
      }

    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, $pathBack = null)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListCat')->pluck('PERMISSIONS')[0] == "1"){

        $cat = Category::findOrFail($id);
        if(!$pathBack){
            $pathBack = route('category.index', $cat->PARENT_ID);
        }
        $getParent = DB::table('categories')->where('CATEGORY_ID','=', $id)->get();
        $idCrumb = $id;
        $crumb = TRUE;
        $crumbArray = [];
        while ($crumb == TRUE) {
            if ($idCrumb != -1) {
                $getParent2 = DB::table('categories')->where('CATEGORY_ID','=', $idCrumb)->get();
                $idCrumb = $getParent2[0]->PARENT_ID;
                $menubreadcrumb = DB::table('categories')->where('PARENT_ID','=', $idCrumb)->get();

                array_push($crumbArray, $menubreadcrumb);

            }else{
                $crumb == FALSE;
                break;
            }
        }
        $crumbArray = array_reverse($crumbArray);

        return view($this->prefixViewDir . 'edit')->with(['category'=> $cat, 'pathBack' => $pathBack])->with('breadcrumb', $crumbArray)->with('pgId', $id)->with('parentId', $getParent);;

      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListCat')->pluck('PERMISSIONS')[0] == "1"){
        $request->validate([
                'name' => 'required|min:3|max:50',
            ],
            [
                'required' => Lang::get('system.edit-error-name-required'),
                'min' => Lang::get('system.edit-error-name-min'),
                'max' => Lang::get('system.edit-error-name-max'),

            ]);

        $request->session()->flash('alert-success', Lang::get('system.updated-category-success'));

        $cat = Category::findOrFail($id);
        $cat->NAME = $request->input('name');
        $cat->PARENT_ID = $request->input('category');

        $cat->STATUS = $request->input('status') == 'on' ? 1 : 0;

        $cat->save();
        return redirect()->route('category.index');
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListCat')->pluck('PERMISSIONS')[0] == "1"){
        $category = Category::findOrFail($id);
        $parentCategoryId = $category->PARENT_ID;

        //Update childs categories to link to the parent of the deleted category
        Category::where('PARENT_ID', $category->CATEGORY_ID)->update(['PARENT_ID'=> $parentCategoryId]);
        // Update the articles assossiate to this category id and assosiate it to the father of them
        Article::where('CATEGORY', $category->CATEGORY_ID)->update(['CATEGORY'=> $parentCategoryId]);


        // Remove that single category from sections with that category assossiated
        $section = Section::where([
            'TYPE' => 'categories',
            'ITEMID' => $id
        ])->update([
            'ITEMID'=> null
        ]);

        $category->delete();
        return redirect()->route('category.index');
      }else{
        return redirect()->route('home');
      }
    }
}
