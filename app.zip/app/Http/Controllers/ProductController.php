<?php

namespace App\Http\Controllers;

use App\Product;
use App\ProductFile;
use App\ProductLang;
use App\ProductCategory;
use App\ProductCategoryFile;
use App\ProductCategoryLang;
use App\Languages;
use App\Section;
use App\SectionProduct;
use App\Rank;
use App\AttributeProduct;
use App\Crico;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDir = '';

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDir = 'backoffice.product.';
    }

    public function index()
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $product = DB::table('product')
                ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
                ->where('product_lang.LANGUAGE_ID', '=', '1')
                ->where('product.PARENT_ID', '=', '-1')
                ->select('product.*', 'product_lang.*')
                ->orderBy('product.PRODUCT_ID','ASC')
                ->get();
            foreach ($product as $k => $p) {
                $view = DB::table('product')->where('PARENT_ID','=',$p->PRODUCT_ID)->get();
                $view2[] = count($view);
            }
            $view2[] = "";
            $product_cat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->where('product_category.C_PARENT_ID', '=', '-1')
                ->select('product_category.*', 'product_category_lang.*')
                ->orderBy('product_category.C_PRODUCT_ID','ASC')
                ->get();
            $haveProd = "";
            $haveProdArray = [];
            foreach ($product_cat as $k => $pc) {
                $haveProd = Product::where('PARENT_ID', $pc->C_PRODUCT_ID)->get();
                $cview = DB::table('product_category')->where('C_PARENT_ID','=',$pc->C_PRODUCT_ID)->get();
                $cview2[] = count($cview);
                array_push($haveProdArray, $haveProd);
            }
            $cview2[] = "";
            return view($this->prefixViewDir . 'productList')
                ->with('products', $product)
                ->with('view', $view2)
                ->with('products_category', $product_cat)
                ->with('haveProd', $haveProdArray)
                ->with('cview', $cview2);
        }else{
          return redirect()->route('home');
        }
    }

    public function productview(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
		$product = DB::table('product')
            ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
			->where('product_lang.LANGUAGE_ID', '=', '1')
			->where('product.PARENT_ID', '=', $id)
            ->select('product.*', 'product_lang.*')
            ->orderBy('ORDER')
            ->get();
		$productCat = DB::table('product_category')
            ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
			->where('product_category_lang.LANGUAGE_ID', '=', '1')
			->where('product_category.C_PARENT_ID', '=', $id)
            ->select('product_category.*', 'product_category_lang.*')
            ->orderBy('ORDER')
            ->get();

        $haveProd = "";
        $haveProdArray = [];
		foreach ($productCat as $k => $p) {
            $haveProd = Product::where('PARENT_ID', $p->C_PRODUCT_ID)->get();
			$view = DB::table('product_category')
                ->where('C_PARENT_ID','=',$p->C_PRODUCT_ID)
                ->get();
			$view2[] = count($view);
            array_push($haveProdArray, $haveProd);
		}

		$view2[] = "";
		$getParent = DB::table('product_category')->where('C_PRODUCT_ID','=',$id)->get();
        $idCrumb = $id;
        $crumb = TRUE;
        $crumbArray = [];
        $saves_ids = [];
        while ($crumb == TRUE) {
            if ($idCrumb != -1 ) {
                $getParent2 = DB::table('product_category')->where('C_PRODUCT_ID','=',$idCrumb)->select('C_PARENT_ID')->get();
                array_push($saves_ids, $idCrumb);
                $idCrumb = $getParent2[0]->C_PARENT_ID;

            }else{
                $crumb == FALSE;
                break;
            }
        }
        if (!empty($saves_ids)) {
            foreach ($saves_ids as $key => $sid) {
                $menubreadcrumb = DB::table('product_category')
                    ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
        			->where('product_category_lang.LANGUAGE_ID', '=', '1')
        			->where('product_category.C_PRODUCT_ID', '=', $sid)
                    ->select('product_category.*', 'product_category_lang.*')
                    ->orderBy('ORDER')
                    ->get();

                array_push($crumbArray, $menubreadcrumb);

            }
        }
        $crumbArray = array_reverse($crumbArray);
        return view($this->prefixViewDir . 'productView')
            ->with('product', $product)
            ->with('productCat', $productCat)
            ->with('view', $view2)
            ->with('haveProd', $haveProdArray)
            ->with('backid', $getParent)
            ->with('breadcrumb', $crumbArray)
            ->with('pgId', $id);
      }else{
        return redirect()->route('home');
      }
    }

    public function productadd(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddProduct')->pluck('PERMISSIONS')[0] == "1"){
    		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
    		$product = DB::table('product')
                ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
    			->where('product_lang.LANGUAGE_ID', '=', '1')
                ->select('product.*', 'product_lang.*')
                ->get();
            $productCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
    			->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*')
                ->get();

    		$tabsAdjust = count($langs);
    		$tabsAdjust = 100 / $tabsAdjust;
            $attrs = DB::table('attribute_name')
                ->where('LANGUAGE_ID', '=', '1')
                ->get();

            foreach ($attrs as $key => $attr) {
                $attrValues = DB::table('attribute_value')
                    ->where('LANGUAGE_ID', '=', '1')
                    ->where('ATTRIBUTE_ID', '=', $attr->ATTRIBUTE_ID)
                    ->get();
                $attrs[$key]->childs = $attrValues;
            }

            return view($this->prefixViewDir . 'productAdd')->with(
                [
                    'langs'=> $langs,
                    'tabsajust' => $tabsAdjust,
                    'product' => $product,
                    'productCat' => $productCat,
                    'attributes' => $attrs
                ]);
      }else{
        return redirect()->route('home');
      }
    }

    public function insert(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->get();
        $this->validation($req, $langs);
		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

        if($req->input("status") == TRUE){
			$status = 1;
		}
		$product = DB::table('product')->insertGetId([
            'PARENT_ID' => $req->input("parent"),
            'STATUS' => $status,
            'CODE' => $req->input("prodcode"),
            'PRICE' => $req->input("price"),
            'STOCK' => (!empty($req->input("stock"))) ? $req->input("stock") : "0" ,
            'DISCOUNT' => (!empty($req->input("discount"))) ? $req->input("discount") : "0" ,
            'DISCOUNT_TYPE' => (!empty($req->input("discountType"))) ? $req->input("discountType") : "fix" ,
            'DISCOUNT_INIT' => $req->input("discountInit"),
            'DISCOUNT_END' => $req->input("discountEnd"),
            'DISCOUNT_PARENT' => (!empty($req->input("discountParent") && $req->input("discountParent") == "on")) ? "1" : "0" ,
            'DESTAQUE' => $req->input("destaque") === 'on' ? 1 : 0,
            'ORDER' => (!empty($req->input("order"))) ? $req->input("order") : "0" ,
        ]);
        $this->customCamps($req, $product);

        if(!empty($req->input('attribute'))){
            $attributes = $req->input('attribute');
            $attribute_values = $req->input('attribute2');
            $attribute_price = $req->input('attribute_price');
            $i=1;
            foreach($attributes as $key => $attribute){
                $attribute_values_k = $attribute_values[$key];
                $attribute_price_k = $attribute_price[$key];
                DB::table('attribute_product')->insertGetId([
                    'ATTRIBUTE_ID' => $attribute["ATTRIBUTE_ID"],
                    'ATTRIBUTE_VALUE_ID' => $attribute_values_k["ATTRIBUTE_ID"],
                    'PRODUCT_ID' => $product,
                    'A_PRICE' => $attribute_price_k["ATTRIBUTE_ID"],
                    'ORDER' => $i
                ]);
                $i++;
            }
        }

        if ($req->input("image_code")){
            $index=1;
            foreach ($req->input("image_code") as $image_id => $image_code) {
                $product_file = new ProductFile();
                $product_file->PRODUCT_ID = $product;
                $product_file->FILE_ID = $image_id;
                $product_file->CODE = $image_code === null ? '' : $image_code;
                $product_file->ORDER = $index;
                $product_file->save();
                $index++;
            }
        }

        foreach ($langs as $l => $lang) {
			DB::table('product_lang')->insert([
                'PRODUCT_ID' => $product,
                'LANGUAGE_ID' => $lang->LANGUAGE_ID,
                'NAME' => $req->input("name_{$lang->SLUG}"),
                'DESCRIPTION' => $req->input("description_{$lang->SLUG}")
            ]);

		}

        return redirect()->route('productList');
      }else{
        return redirect()->route('home');
      }
    }

	public function productedit(Request $req, $id, $idParent){
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
    		$langs = DB::table('a_languages')
				->join('product_lang', 'product_lang.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
				->where('product_lang.PRODUCT_ID', '=', $id)
				->select('a_languages.LANGUAGE_ID', 'a_languages.NAME AS LG_NAME','a_languages.SLUG','a_languages.STATUS','product_lang.*')
				->orderBy('STATUS', 'desc')
				->get();
    		$product = DB::table('product')->select('product.*')->where('PRODUCT_ID', $id)->get();
    		$product2 = DB::table('product')
                ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
    			->where('product_lang.LANGUAGE_ID', '=', '1')
                ->select('product.*', 'product_lang.*')
                ->get();
            $productCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                ->join('product', 'product_category.C_PRODUCT_ID', '=', 'product.PARENT_ID')
                ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*', 'product.*')
                ->get();
            $Cat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*')
                ->get();

    		$tabsajust = count($langs);
    		try{
    		    $tabsajust = 100 / $tabsajust;
            }catch (\Exception $e){
    		    abort(404);
            }

            $attrs = DB::table('attribute_name')
                ->where('LANGUAGE_ID', '=', '1')
                ->get();

            foreach ($attrs as $key => $attr) {
                $attrValues = DB::table('attribute_value')
                    ->where('LANGUAGE_ID', '=', '1')
                    ->where('ATTRIBUTE_ID', '=', $attr->ATTRIBUTE_ID)
                    ->get();
                $attrs[$key]->childs = $attrValues;
            }

            $attrs_db = db::table('attribute_product')->where("PRODUCT_ID", $id)->orderBy('ORDER','ASC')->get();

            // $getParent = DB::table('product')->where('PRODUCT_ID','=',$id)->get();


            $breadCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
    			->where('product_category_lang.LANGUAGE_ID', '=', '1')
    			->where('product_category.C_PARENT_ID', '=', $idParent)
                ->select('product_category.*', 'product_category_lang.*')
                ->orderBy('ORDER')
                ->get();
            foreach ($Cat as $k => $p) {
    			$view = DB::table('product_category')
                    ->where('C_PARENT_ID','=',$p->C_PRODUCT_ID)
                    ->get();
    			$view2[] = count($view);
    		}
    		$view2[] = "";
    		$getParent = DB::table('product_category')->where('C_PRODUCT_ID','=',$idParent)->get();
            $idCrumb = $idParent;
            $crumb = TRUE;
            $crumbArray = [];
            $saves_ids = [];
            while ($crumb == TRUE) {
                if ($idCrumb != -1 ) {
                    $getParent2 = DB::table('product_category')->where('C_PRODUCT_ID','=',$idCrumb)->select('C_PARENT_ID')->get();
                    array_push($saves_ids, $idCrumb);
                    $idCrumb = $getParent2[0]->C_PARENT_ID;

                }else{
                    $crumb == FALSE;
                    break;
                }
            }
            if (!empty($saves_ids)) {
                foreach ($saves_ids as $key => $sid) {
                    $menubreadcrumb = DB::table('product_category')
                        ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
            			->where('product_category_lang.LANGUAGE_ID', '=', '1')
            			->where('product_category.C_PRODUCT_ID', '=', $sid)
                        ->select('product_category.*', 'product_category_lang.*')
                        ->orderBy('ORDER')
                        ->get();

                    array_push($crumbArray, $menubreadcrumb);

                }
            }
            $crumbArray = array_reverse($crumbArray);
            $product_file = ProductFile::where('PRODUCT_ID', $id)->orderby('ORDER','ASC')->get();
    		return view($this->prefixViewDir . 'productEdit')->with(
    		    [
    		        'langs'=> $langs,
                    'tabsajust'=> $tabsajust,
                    'product2'=> $product2,
                    'idback'=> $id,
                    'parentId'=> $idParent,
                    'product'=> $product,
                    'productCat'=> $productCat,
                    'cat'=> $Cat,
                    'product_file'=> $product_file,
                    'breadcrumb'=> $crumbArray,
                    'pgId'=> $id,
                    'attributes' => $attrs,
                    "attributes_db" => $attrs_db
                ]);
        }else{
          return redirect()->route('home');
        }
	}
	public function replicate($id){
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $product_replicate = Product::findOrFail($id);
            $product = $product_replicate->replicate();
            $product->save();

            if (ProductLang::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)) {
                foreach (ProductLang::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get() as $product_lang_replicate) {
                    $product_lang = $product_lang_replicate->replicate();
                    $product_lang->PRODUCT_ID = $product->PRODUCT_ID;
                    $product_lang->save();
                }
            }

            if (ProductFile::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)) {
                foreach (ProductFile::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get() as $product_file_replicate) {
                    $product_file = $product_file_replicate->replicate();
                    $product_file->PRODUCT_ID = $product->PRODUCT_ID;
                    $product_file->save();
                }
            }
            if (AttributeProduct::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)) {
                foreach (AttributeProduct::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get() as $product_attribute_replicate) {
                    $product_attribute = $product_attribute_replicate->replicate();
                    $product_attribute->PRODUCT_ID = $product->PRODUCT_ID;
                    $product_attribute->save();
                }
            }

    		$langs = DB::table('a_languages')
				->join('product_lang', 'product_lang.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
				->where('product_lang.PRODUCT_ID', '=', $product_replicate->PRODUCT_ID)
				->select('a_languages.LANGUAGE_ID', 'a_languages.NAME AS LG_NAME','a_languages.SLUG','a_languages.STATUS','product_lang.*')
				->orderBy('STATUS', 'desc')
				->get();
    		$product = DB::table('product')->select('product.*')->where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get();
    		$product2 = DB::table('product')
                ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
    			->where('product_lang.LANGUAGE_ID', '=', '1')
                ->select('product.*', 'product_lang.*')
                ->get();
            $productCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                ->join('product', 'product_category.C_PRODUCT_ID', '=', 'product.PARENT_ID')
                ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*', 'product.*')
                ->get();
            $Cat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*')
                ->get();
    		$tabsajust = count($langs);
    		try{
    		    $tabsajust = 100 / $tabsajust;
            }catch (\Exception $e){
    		    abort(404);
            }

            $attrs = DB::table('attribute_name')
                ->where('LANGUAGE_ID', '=', '1')
                ->get();

            foreach ($attrs as $key => $attr) {
                $attrValues = DB::table('attribute_value')
                    ->where('LANGUAGE_ID', '=', '1')
                    ->where('ATTRIBUTE_ID', '=', $attr->ATTRIBUTE_ID)
                    ->get();
                $attrs[$key]->childs = $attrValues;
            }

            $idParent = $product_replicate->PARENT_ID;
            $getParent = DB::table('product')->where('PRODUCT_ID','=',$product_replicate->PRODUCT_ID)->get();
            $breadCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
    			->where('product_category_lang.LANGUAGE_ID', '=', '1')
    			->where('product_category.C_PARENT_ID', '=', $idParent)
                ->select('product_category.*', 'product_category_lang.*')
                ->orderBy('ORDER')
                ->get();
            foreach ($Cat as $k => $p) {
    			$view = DB::table('product_category')
                    ->where('C_PARENT_ID','=',$p->C_PRODUCT_ID)
                    ->get();
    			$view2[] = count($view);
    		}
    		$view2[] = "";
    		$getParent = DB::table('product_category')->where('C_PRODUCT_ID','=',$idParent)->get();
            $idCrumb = $idParent;
            $crumb = TRUE;
            $crumbArray = [];
            $saves_ids = [];
            while ($crumb == TRUE) {
                if ($idCrumb != -1 ) {
                    $getParent2 = DB::table('product_category')->where('C_PRODUCT_ID','=',$idCrumb)->select('C_PARENT_ID')->get();
                    array_push($saves_ids, $idCrumb);
                    $idCrumb = $getParent2[0]->C_PARENT_ID;

                }else{
                    $crumb == FALSE;
                    break;
                }
            }
            if (!empty($saves_ids)) {
                foreach ($saves_ids as $key => $sid) {
                    $menubreadcrumb = DB::table('product_category')
                        ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
            			->where('product_category_lang.LANGUAGE_ID', '=', '1')
            			->where('product_category.C_PRODUCT_ID', '=', $sid)
                        ->select('product_category.*', 'product_category_lang.*')
                        ->orderBy('ORDER')
                        ->get();

                    array_push($crumbArray, $menubreadcrumb);

                }
            }
            $crumbArray = array_reverse($crumbArray);
            $product_file = ProductFile::where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get();
            $attrs_db = db::table('attribute_product')->where('PRODUCT_ID', $product_replicate->PRODUCT_ID)->get();
    		return view($this->prefixViewDir . 'productEdit')->with(
    		    [
    		        'langs'=> $langs,
                    'tabsajust'=> $tabsajust,
                    'product2'=> $product2,
                    'idback'=> $product_replicate->PRODUCT_ID,
                    'parentId'=> $product[0]->PARENT_ID,
                    'product'=> $product,
                    'productCat'=> $productCat,
                    'cat'=> $Cat,
                    'product_file'=> $product_file,
                    'breadcrumb'=> $crumbArray,
                    'pgId'=> $product_replicate->PRODUCT_ID,
                    'attributes' => $attrs,
                    'attributes_db'=> $attrs_db,
                ]);
        }else{
          return redirect()->route('home');
        }
	}

    public function update(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')
            ->select('LANGUAGE_ID', 'NAME', 'SLUG','STATUS')
            ->get();
        $this->validation($req, $langs);

		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

		if($req->input("status") == TRUE){
			$status = 1;
		}
		DB::table('product')
            ->where('PRODUCT_ID', $id)
            ->update([
                'PARENT_ID' => $req->input("parent"),
                'status' => $status,
                'CODE' => $req->input("prodcode"),
                'PRICE' => $req->input("price"),
                'STOCK' => (!empty($req->input("stock"))) ? $req->input("stock") : "0" ,
                'DISCOUNT' => (!empty($req->input("discount"))) ? $req->input("discount") : "0" ,
                'DISCOUNT_TYPE' => (!empty($req->input("discountType"))) ? $req->input("discountType") : "fix" ,
                'DISCOUNT_INIT' => $req->input("discountInit"),
                'DISCOUNT_END' => $req->input("discountEnd"),
                'DISCOUNT_PARENT' => (!empty($req->input("discountParent") && $req->input("discountParent") == "on")) ? "1" : "0" ,
                'DESTAQUE' => $req->input("destaque") === 'on' ? 1 : 0,
                'ORDER'=> $req->input("order")
            ]);
        $this->customCamps2($req, $id);


        DB::table('attribute_product')->where('PRODUCT_ID',$id)->delete();

        if(!empty($req->input('attribute'))){
            $attributes = $req->input('attribute');
            $attribute_values = $req->input('attribute2');
            $attribute_price = $req->input('attribute_price');
            $i = 1;
            foreach($attributes as $key => $attribute){
                $attribute_values_k = $attribute_values[$key];
                $attribute_price_k = $attribute_price[$key];
                DB::table('attribute_product')->insertGetId([
                    'ATTRIBUTE_ID' => $attribute["ATTRIBUTE_ID"],
                    'ATTRIBUTE_VALUE_ID' => $attribute_values_k["ATTRIBUTE_ID"],
                    'PRODUCT_ID' => $id,
                    'A_PRICE' => $attribute_price_k["ATTRIBUTE_ID"],
                    'ORDER' => $i
                ]);
                $i++;
            }
        }

        foreach (ProductFile::where('PRODUCT_ID', $id)->get() as $value) {
            $value->delete();
        }

        if ($req->input("image_code")){
            $index=1;
            foreach ($req->input("image_code") as $image_id => $image_code) {
                $product_file = new ProductFile();
                $product_file->PRODUCT_ID = $id;
                $product_file->FILE_ID = $image_id;
                $product_file->CODE = $image_code === null ? '' : $image_code;
                $product_file->ORDER = $index;
                $product_file->save();
                $index++;
            }
        }

		foreach ($langs as $l => $lang) {
			DB::table('product_lang')
                ->where('PRODUCT_ID', $id)
                ->where('LANGUAGE_ID', $lang->LANGUAGE_ID)
                ->update([
                    'PRODUCT_ID' => $id,
                    'LANGUAGE_ID' => $lang->LANGUAGE_ID,
                    'NAME' => $req->input("name_{$lang->SLUG}"),
                    'DESCRIPTION' => $req->input("description_{$lang->SLUG}")
                ]);
		}
        return redirect()->route('productList');
      }else{
        return redirect()->route('home');
      }
    }
	public function remove(Request $req, $id) {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
    		DB::table('product')->where('PRODUCT_ID', '=', $id)->delete();
    		DB::table('product_lang')->where('PRODUCT_ID', '=', $id)->delete();
    		DB::table('product_file')->where('PRODUCT_ID', '=', $id)->delete();
    		DB::table('attribute_product')->where('PRODUCT_ID', $id)->delete();

            Section::where([
                'TYPE' => 'product',
                'ITEMID' => $id
            ])->update([
                'ITEMID' => null
            ]);

            foreach(SectionProduct::where('PRODUCT_ID', $id)->get() as $product_section){
                $product_section->delete();
            }

            $req->session()->flash('alert-success', Lang::get('system.product-removeProduct-success'));
            return back();
        }else{
        return redirect()->route('home');
        }
	}
    public function customCamps(Request $request, $prod_id){

        if(!$request->input('custom_camps')) {
            return;
        }
        $custom_camps = '{';

        foreach($request->input('custom_camps') as $key => $custom_camp){
            if(!empty($custom_camp['key'])){
                $custom_camps .= '"' . $custom_camp['key'] . '":"' . $custom_camp['value'] . '"';
                if (!($key === array_key_last($request->input('custom_camps')))){
                    $custom_camps .= ',';
                }
            }
        }
        $custom_camps .= '}';
        DB::table('product')->where('PRODUCT_ID',$prod_id)->update(['CUSTOMCAMPS' => $custom_camps]);
    }
    public function customCamps2(Request $request, $idprod){
        function merge($a1, $a2) {
            $aRes = $a1;
            foreach ( array_slice ( func_get_args (), 1 ) as $aRay ) {
                foreach ( array_intersect_key ( $aRay, $aRes ) as $key => $val )
                    $aRes [$key] += $val;
                $aRes += $aRay;
            }
            return $aRes;
        }

        if(!$request->input('custom_camps')) {
            return;
        }
        $custom_camps = '{';

        foreach($request->input('custom_camps') as $key => $custom_camp){
            if(!empty($custom_camp['key'])){
                $custom_camps .= '"' . $custom_camp['key'] . '":"' . $custom_camp['value'] . '"';
                if (!($key === array_key_last($request->input('custom_camps')))){
                    $custom_camps .= ',';
                }
            }
        }
        $custom_camps .= '}';
        if(empty($request->custom_camp)){
            $cscamp = $custom_camps;
        }elseif (empty($custom_camps)) {
            $cscamp = $request->custom_camp;
        }else{
            $cscamp = json_encode(merge($request->custom_camp,json_decode($custom_camps, true)));
        }
        DB::table('product')->where('PRODUCT_ID',$idprod)->update(['CUSTOMCAMPS' => $cscamp]);
    }


    public function validation(Request $request, Collection $languages){


        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:90'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),
            ]
        );
    }
}
