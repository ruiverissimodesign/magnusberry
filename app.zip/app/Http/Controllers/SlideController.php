<?php

namespace App\Http\Controllers;

use App\Banner;
use App\BannerItem;
use App\BannerItemLang;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Slide;
use App\Section;
use App\Rank;
use Auth;

class SlideController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.slide.';
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function slidelist(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
    		$slide = DB::table('e_banner')->get();
        return view($this->prefixViewDirFiles . 'slideList')->with('slides', $slide);
      }else{
        return redirect()->route('home');
      }
    }
    public function slideitemlist(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
		$slide = DB::table('e_banner_item')
				->join('files', 'e_banner_item.IMG_ID', '=', 'files.FILE_ID')
				->where('BANNER_ID', $id)
				->select('e_banner_item.*','files.FILE')
                ->orderBy('ORDER')
				->get();

        $parent = DB::table('e_banner')->where('BANNER_ID', '=', $id)->get();
        return view($this->prefixViewDirFiles . 'slideItemList')->with('slides', $slide)->with('idback', $id)->with('crumb', $parent);
      }else{
        return redirect()->route('home');
      }
    }
    public function slideadd(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSlide')->pluck('PERMISSIONS')[0] == "1"){
        $teamplates = DB::table('teamplate')->where('TYPE','banner')->get();
        return view($this->prefixViewDirFiles . 'slideAdd')->with('teamplates',$teamplates);
      }else{
        return redirect()->route('home');
      }
    }
    public function slideitemadd(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSlide')->pluck('PERMISSIONS')[0] == "1"){
		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
		$tabsajust = count($langs);
		$tabsajust = 100 / $tabsajust;
        $parentName = DB::table('e_banner')->where('BANNER_ID', $id)->get();
        return view($this->prefixViewDirFiles . 'slideItemAdd')->with('langs', $langs)->with('tabsajust', $tabsajust)->with('idback', $id)->with('crumbName', $parentName);
      }else{
        return redirect()->route('home');
      }
    }
	public function insertitem(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSlide')->pluck('PERMISSIONS')[0] == "1"){
          $validate = $req->validate([
      	        'imgid'=>'required',
                [
                    'required' => \Lang::get('system.edit-error-name-required')
                ]
          ]);
		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG')->get();
		$item = DB::table('e_banner_item')->insertGetId(['BANNER_ID' => $id, 'IMG_ID' => $req->input("imgid")]);
		foreach ($langs as $l => $lang) {
			DB::table('e_banner_item_lang')->insert(['BANNER_ITEM_ID' => $item, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'TITLE' => $req->input("title_{$lang->SLUG}"), 'SUBTITLE' => $req->input("subtitle_{$lang->SLUG}"), 'LINK_NAME' => $req->input("link_name_{$lang->SLUG}"), 'LINK' => $req->input("link_{$lang->SLUG}")]);
		}
        return redirect()->route('slideItemList', $id)->withErrors($validate);
      }else{
        return redirect()->route('home');
      }
    }
	public function insert(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSlide')->pluck('PERMISSIONS')[0] == "1"){
          $validate = $req->validate([
      	        'name'=>'required',
                [
                    'required' => \Lang::get('system.edit-error-name-required')
                ]
          ]);
		DB::table('e_banner')->insert(['NAME' => $req->name, 'TEAMPLATE' => $req->select_tp]);
        return redirect()->route('slide')->withErrors($validate);
      }else{
        return redirect()->route('home');
      }
    }
	public function update(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
          $validate = $req->validate([
      	        'name'=>'required',
                [
                    'required' => \Lang::get('system.edit-error-name-required')
                ]
          ]);
		DB::table('e_banner')->update(['NAME' => $req->name, 'TEAMPLATE' => $req->select_tp]);
        return redirect()->route('slide')->withErrors($validate);
      }else{
        return redirect()->route('home');
      }
    }
	public function slideedit(Request $req, $id)
	{
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
		$slide = DB::table('e_banner')->where('BANNER_ID', $id)->get();
    $teamplates = DB::table('teamplate')->where('TYPE','banner')->get();
		return view($this->prefixViewDirFiles . 'slideEdit')->with('slide', $slide)->with('teamplates', $teamplates);
  }else{
    return redirect()->route('home');
  }
	}
	public function slideitemedit(Request $req, $id, $idbanner)
	{
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
		$langs = DB::table('a_languages')
					->join('e_banner_item_lang', 'e_banner_item_lang.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
					->where('e_banner_item_lang.BANNER_ITEM_ID', '=', $id)
					->select('a_languages.*','e_banner_item_lang.*')
					->orderBy('STATUS', 'desc')
					->get();
		$slide = DB::table('e_banner_item')->select('BANNER_ITEM_ID', 'BANNER_ID', 'IMG_ID')->where('BANNER_ITEM_ID', $id)->get();
        // dd($slide);
		$tabsajust = count($langs);
		$tabsajust = 100 / $tabsajust;
        $parentName = DB::table('e_banner')->where('BANNER_ID', $idbanner)->get();
		return view($this->prefixViewDirFiles . 'slideItemEdit')->with('langs', $langs)->with('tabsajust', $tabsajust)->with('slide', $slide)->with('idback', $id)->with('idbanner', $idbanner)->with('crumbName', $parentName);
  }else{
    return redirect()->route('home');
  }
	}
	public function updateitem(Request $req, $id, $idbanner)
	{
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
        $validate = $req->validate([
              'imgid'=>'required',
              [
                  'required' => \Lang::get('system.edit-error-name-required')
              ]
        ]);
		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG')->where('status', 1)->get();
		DB::table('e_banner_item')->where('BANNER_ITEM_ID', $id)->update(['IMG_ID' => $req->input("imgid")]);
		foreach ($langs as $l => $lang) {
			DB::table('e_banner_item_lang')->where('BANNER_ITEM_ID', $id)->where('LANGUAGE_ID', $lang->LANGUAGE_ID)->update(['BANNER_ITEM_ID' => $id, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'TITLE' => $req->input("title_{$lang->SLUG}"), 'SUBTITLE' => $req->input("subtitle_{$lang->SLUG}"), 'LINK_NAME' => $req->input("link_name_{$lang->SLUG}"), 'LINK' => $req->input("link_{$lang->SLUG}")]);
		}
		return redirect()->route('slideItemList', $idbanner)->withErrors($validate);
  }else{
    return redirect()->route('home');
  }
	}
	public function remove(Request $req, $id) {
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
        Banner::where('BANNER_ID', $id)->first()->delete();

        foreach(BannerItem::where('BANNER_ID', $id)->get() as $banner_item){
            foreach(BannerItemLang::where('BANNER_ITEM_ID', $banner_item->BANNER_ITEM_ID)->get() as $banner_item_trad)
            {
                $banner_item_trad->delete();
            }
            $banner_item->delete();
        }



       	Section::where([
            'TYPE' => 'slideshow',
            'ITEMID' => $id
        ])->update([
            'ITEMID'=> null
        ]);

		return redirect()->route('slide');
  }else{
    return redirect()->route('home');
  }
	}
	public function removeitem(Request $req, $id, $idbanner = null) {
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSlide')->pluck('PERMISSIONS')[0] == "1"){
		DB::table('e_banner_item')->where('BANNER_ITEM_ID', '=', $id)->delete();
		DB::table('e_banner_item_lang')->where('BANNER_ITEM_ID', '=', $id)->delete();
		if($idbanner){
		    return redirect()->route('slideItemList', $idbanner);
        }else{
		    return back();
        }
      }else{
        return redirect()->route('home');
      }
	}
}
