<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rank;
use App\GoogleAnalytics;
use Auth;
use Analytics;
use Spatie\Analytics\Period;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.';
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if(true){
            return redirect()->route('company.index');
        }
        $result = GoogleAnalytics::topCountries();
        $resultVisit = GoogleAnalytics::allVisitors();
        $live = GoogleAnalytics::liveUsers();
        $device = GoogleAnalytics::device();

        return view($this->prefixViewDirFiles . 'home', compact('result','resultVisit','device'));
    }
    public function getLiveUsers()
    {
        $live = GoogleAnalytics::liveUsers();

        return $live;
    }
}
