<?php

namespace App\Http\Controllers;

use App\File;
use ErrorException;
use Carbon\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Intervention\Image\Facades\Image;
use App\Http\Requests\FileEditRequest;
use Illuminate\Support\Facades\Storage;
use App\FileLang;
use App\ArticleFile;
use App\ProductFile;
use App\ProductCategoryFile;
use App\SectionFile;
use App\BannerItem;
use App\BannerItemLang;
use App\Rank;
use Auth;

//TODO: Adicionar descriçaõ mas várias linguagens disponives
/**
 * This class handles the files uploads and crops
 *
 *
 * ------------- IMPORTANT ----------------------
 *
 * If this controller has been doing errors
 * It might be due to not linking storage to public
 * Run php artusan storage:link
 *
 * Other Error:
 *  - Allowed memory size of x bytes exhausted (tried to allocate y bytes)
 *      - For this error you need to change your php.ini in the server ("memory_limit" is the name of the camp, you need to put this to a higher value or -1)
 *
 * -----------------------------------------------
 */
class FileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDirFiles;
    public static $WIDTH_IMAGE_SMALL;
    public static $WIDTH_IMAGE_MEDIUM;

    function __construct(){
        $this->prefixViewDirFiles = 'backoffice.files.';
        $this->middleware('auth');
    }


    public function index()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        $files = File::all();
        return view($this->prefixViewDirFiles . 'index', compact('files'));
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
          $page = $request->input('page');

        if ($request->file('file')) {
            foreach($request->file('file') as $file){
                //Instanciate file object
                $dbFileObject = new File;
                //get filename with extension
                Log::info('Created the db object');
                $filenamewithextension = $file->getClientOriginalName();
                Log::info('Set the filenamewithextension to ' . $filenamewithextension);

                $filename = str_replace('.'. $file->getClientOriginalExtension(), '', $filenamewithextension);
                $dbFileObject->IMAGENAME = $filename;
                Log::info('Set the IMAGENAME to ' . $filename);

                $dbFileObject->ASSOCIATION = $page;


                //get file extension
                $extension = strtolower( $file->getClientOriginalExtension());
                $dbFileObject->TYPE = $extension;
                Log::info('Set the extension to ' . $extension);

                //filename to store
                function cleanString($text) {
                $utf8 = array(
                   '/[áàâãªä]/u'   =>   'a',
                   '/[ÁÀÂÃÄ]/u'    =>   'A',
                   '/[ÍÌÎÏ]/u'     =>   'I',
                   '/[íìîï]/u'     =>   'i',
                   '/[éèêë]/u'     =>   'e',
                   '/[ÉÈÊË]/u'     =>   'E',
                   '/[óòôõºö]/u'   =>   'o',
                   '/[ÓÒÔÕÖ]/u'    =>   'O',
                   '/[úùûü]/u'     =>   'u',
                   '/[ÚÙÛÜ]/u'     =>   'U',
                   '/ç/'           =>   'c',
                   '/Ç/'           =>   'C',
                   '/ñ/'           =>   'n',
                   '/Ñ/'           =>   'N',
                   '/–/'           =>   '-', // UTF-8 hyphen to "normal" hyphen
                   '/[’‘‹›‚]/u'    =>   ' ', // Literally a single quote
                   '/[“”«»„]/u'    =>   ' ', // Double quote
                   '/ /'           =>   ' ', // nonbreaking space (equiv. to 0x160)
                );
                return preg_replace(array_keys($utf8), array_values($utf8), $text);
                }
                $characteresnoallowed = ["/","^","!","#","$","&",";","=","?","-","[","]","~","+"];
                $filename = cleanString($filename);
                $filename = str_replace($characteresnoallowed,"",$filename);
                $filename = str_replace(" ","_",$filename);
                $filenametostore = $filename.'_' . uniqid() . '.'.$extension;
                $dbFileObject->FILE = $filenametostore;
                Log::info('Set the $filenametostore to ' . $filenametostore);

                try{
                    Log::info('Trying to create file in file/original folder');

                    Storage::put('files/original/'. $filenametostore, fopen($file, 'r+'));
                    Log::info('file in file/original folder successfully');

                }catch(ErrorException $e){
                    Log::info('file in file/original folder failed');

                    return response()
                            ->json([
                                    'error' => \Lang::get('system.image-error-files-size-error')
                                    ], 400);
                }




                //Checks if the file is a actual image and can be resized, only if the enviroment variable (inside .env) is set to true
                if (FileController::isFileAImage($extension)){

                    // This only informs the modal that this specific file is a image and therefore needs to be treated like that
                    // For example, in edit file, if this is set to 1 it will show the crop
                    // otherwise it will not display the crop option
                    $dbFileObject->ISIMAGE = '1';
                    Log::info('set ISIMAGE to ' . $dbFileObject->ISIMAGE );

                    $dbFileObject->save();
                    Log::info('Saved Object to db: ');
                    Log::info($dbFileObject);


                    if(env('CONVERT_IMAGES_TO_DIFFERENT_SIZES')){
                        // Unfortunatly, resizing images take a great amount of space,
                        // There is a option that takes the limit a bit further
                        // This was necessary because it was givin error
                        //FIXME: Not catching the error by some reason

                        Log::info('Starting the crop process ');

                        Log::info('Trying to create file in file/original small');
                        Storage::put('files/small/'. $filenametostore, fopen($file, 'r+'));
                        Log::info('file in file/small folder successfully');

                        Log::info('Trying to create file in file/original medium');
                        Storage::put('files/medium/'. $filenametostore, fopen($file, 'r+'));
                        Log::info('file in file/medium folder successfully');

                        Log::info('Trying to crop files created previously');
                        $status = FileController::createDifferentSizeImages($filenametostore);



                    }
                }


                $dbFileObject->save();
                Log::info('Added File with name of: ' . $filename);


            }

        }else{
            return response()->json(
                ['error' => \Lang::get('system.image-error-files-not-recieved')],
                 400
                );
        }

        if(isset($status) && $status === 400){
            Log::critical('CROP FAILED');

            return response()->json(
                ['error' => \Lang::get('system.image-error-files-did-create-but-not-resized')],
                400
            );
        }
        Log::info('All went smoothly');
        echo $dbFileObject->FILE_ID;
        // return response()->json(['message' => 'Ficheiros guardados com sucesso'], 200);

      }else{
        return redirect()->route('home');
      }


    }


    public function show($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        $file = File::findOrFail($id);
        return view($this->prefixViewDirFiles . 'show')->withFile($file);
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        $file = File::findOrFail($id);
        $languages = \App\Languages::where('status', '1')->get();
        $trad = FileLang::where('FILE_ID', $file->FILE_ID)->get();
        return view($this->prefixViewDirFiles . 'edit')
            ->withFile($file)
            ->withLanguages($languages)
            ->withTrad($trad);

      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        $validate = $request->validate(
            [
                'file_name' => 'required|max:50|min:3',
            ],
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),

            ]
        );

        $file = File::findOrFail($id);
        $file->update([
            'IMAGENAME' => $request->file_name
        ]);
        $languages = \App\Languages::where('status', 1)->get();

        foreach ($languages as $key => $lang) {

            $description = $request->input("file_description_$lang->SLUG");

            if($description !== null){
                $trad = FileLang::updateOrCreate([
                    'LANGUAGE_ID' => $lang->LANGUAGE_ID,
                    'FILE_ID' => $file->FILE_ID
                ]);

                $trad->DESCRIPTION = $description;

                $trad->save();
            }
        }

        $request->session()->flash('alert-success', \Lang::get('system.changeFile-success'));

        return redirect()->route('file.edit', $id);
      }else{
        return redirect()->route('home');
      }

    }


    public function destroy(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        //Find the file

        $file = File::findOrFail($id);

        //Delete the original one (EVERY FILE AS A ORIGINAL)
        Storage::delete('files/original/' . $file->FILE);

        //If the file is of one of those types, Remove them from others dirs
        if (
            $this->isFileAImage($file->TYPE)
        ){
            Storage::delete([
                'files/small/' .  $file->FILE,
                'files/medium/' .  $file->FILE,

            ]);
        }

        //Eliminar traduções
        $trads = FileLang::where('FILE_ID', $file->FILE_ID)->get();

        foreach ($trads as $trad) {
            $trad->delete();
        }
        //Eliminar Articles Files
        $artcs = ArticleFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($artcs)){
          foreach ($artcs as $artc) {
            $artc->delete();
          }
        }
        $slides = BannerItem::where('IMG_ID', $file->FILE_ID)->get();
        if(!empty($slides)){
          foreach ($slides as $slide) {
            $slide->delete();
            $slidesLang = BannerItemLang::where('BANNER_ITEM_ID', $slide->BANNER_ITEM_ID)->get();
            foreach ($slidesLang as $slideLang) {
              $slideLang->delete();
            }
          }
        }
        //Eliminar Section Files
        $setcs = SectionFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($setcs)){
          foreach ($setcs as $setc) {
              $setc->delete();
          }
        }


        $file->delete();





        $req->session()->flash('alert-success', \Lang::get('system.removefile-success'));
        return redirect()->route('file.index');
      }else{
        return redirect()->route('home');
      }
    }


    public static function createDifferentSizeImages ($filenametostore) {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','Multimedia')->pluck('PERMISSIONS')[0] == "1"){
        try {

            //Resize SMALL image
            Log::info('1');

            $smallImagePath = public_path('storage/files/small/' . $filenametostore);
            Log::info('2');

            $smallImagePath = str_replace('/', '\\', $smallImagePath);
            Log::info('3');

            $img = Image::make($smallImagePath);
            Log::info('4');

            $img_height = $img->height();
            //RESIZE -----------
            Log::info('4');

            $img->resize( env('FILE_IMAGE_WIDTH_SMALL', 300), $img_height);
            //RESIZE !-----------
            Log::info('5');

            $img->save($smallImagePath);
            Log::info('6');

            //RESIZE MEDIUM image
            $mediumImagePath = public_path('storage/files/medium/'.$filenametostore);
            Log::info('7');

            $mediumImagePath = str_replace('/', '\\', $mediumImagePath);
            Log::info('8');

            $img = Image::make($mediumImagePath);
            Log::info('9');

            $img_height = $img->height();
            Log::info('10');

            $img->resize(env('FILE_IMAGE_WIDTH_MEDIUM', 1366), $img_height);
            Log::info('11');

            $img->save($mediumImagePath);
        } catch (\Exception $th) {
            Log::info('--> Erro ao tentar Dar Resize <--');
            Log::info('Error: ' . $th->getMessage());

            return 400;
        }
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Get a type as parameter and checks if that file is actually a image
     *
     * @param [String] $fileType
     * @return boolean
     */
    public static function isFileAImage($fileType) {
        return ( $fileType === 'jpg' ||
                $fileType === 'png' ||
                $fileType === 'jpeg');
    }

}
