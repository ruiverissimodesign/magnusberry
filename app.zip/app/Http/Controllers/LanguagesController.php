<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Languages;
use App\Rank;
use Illuminate\Support\Facades\DB;

class LanguagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.language.';
    }

    /**
     * Show the application dashboard.
     *
     * @return View
     */
    public function index(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListLang')->pluck('PERMISSIONS')[0] == "1"){
		// $user = User::findOrFail($id);
        return view($this->prefixViewDirFiles . 'languages');
      }else{
        return redirect()->route('home');
      }
    }
    public function edit(Request $req, $id , $pathBack = null)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListLang')->pluck('PERMISSIONS')[0] == "1"){
        if(!$pathBack){
            $pathBack = route('languages');
        }
		$languages = Languages::findOrFail($id);
        return view($this->prefixViewDirFiles . 'languageedit')->with(["languages"=> $languages, 'pathBack' => $pathBack]);
      }else{
        return redirect()->route('home');
      }
    }
    public function insert(Request $req)
    {
        if(Auth::user()->rank == "SuperAdmin"){
        return view($this->prefixViewDirFiles . 'languageinsert');
      }else{
        return redirect()->route('home');
      }
    }

	public function create(Request $req) {
    if(Auth::user()->rank == "SuperAdmin"){

		$language = new Languages();
		$validator = $req->validate([
			'name'=>'required',
			'slug'=>'required'
		]);
		$language->NAME = $req->input("name");
		$language->SLUG = strtoupper($req->input("slug"));

		if($req->input("status") == TRUE ) {
			$language->STATUS = 1;
		} else {
			$language->STATUS = 0;
		}

		if ($language->save()) {
			$identificador = DB::getPdo()->lastInsertId();

			// Copiar estas 4 linhas para novas tabelas de linguas (_lang)
			$menus = DB::table('d_menu')->select('MENU_ID')->get();
			foreach ($menus as $m => $menu) {
				DB::table('d_menu_lang')->insert(['MENU_ID'=>$menu->MENU_ID,'LANGUAGE_ID'=>$identificador]);
			}
			// End Copy
			$req->session()->flash('success');
		} else {
			$req->session()->flash('danger');
			return redirect()->route('languages')->withErrors($validator);
		}
		return redirect()->route('languages');
  }else{
    return redirect()->route('home');
  }
	}

	public function update(Request $req, $id) {
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListLang')->pluck('PERMISSIONS')[0] == "1"){
  		$validator = $req->validate([
  			'name'=>'required',
  			'slug'=>'required'
  		]);

  		$language = Languages::findOrFail($id);

  		$language->NAME = $req->input("name");
  		$language->SLUG = strtoupper($req->input("slug"));
  		if($req->input("status") == TRUE ) {
  			$language->STATUS = 1;
  		} else {
  			$language->STATUS = 0;
  		}

  		if ($language->save()) {
  			$req->session()->flash('success');
  		} else {
  			$req->session()->flash('danger');
  			return redirect()->route('languageEdit', ['id'=>$id])->withErrors($validator);
  		}
  		return redirect()->route('languageEdit', ['id'=>$id]);
    }else{
      return redirect()->route('home');
    }
	}

	public function list(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListLang')->pluck('PERMISSIONS')[0] == "1"){
    		$languages = Languages::all();
        return view($this->prefixViewDirFiles . 'languages', compact('languages'));
      }else{
        return redirect()->route('home');
      }
    }
	public function remove(Request $req, $id) {
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListLang')->pluck('PERMISSIONS')[0] == "1"){
  		DB::table("a_languages")->where("LANGUAGE_ID","=",$id)->delete();
  		DB::table("d_menu_lang")->where("LANGUAGE_ID","=",$id)->delete();
  		return redirect()->route('languages');
    }else{
      return redirect()->route('home');
    }
	}
}
