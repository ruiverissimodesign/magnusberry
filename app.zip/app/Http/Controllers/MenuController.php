<?php

namespace App\Http\Controllers;

use App\Page;
use App\Section;
use App\Crico;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Languages;
use Illuminate\View\View;
use App\Rank;
use Auth;

class MenuController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.menu.';
    }


    /**
     * @param Request $req
     * @return View
     */
    public function menuadd(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddMenu')->pluck('PERMISSIONS')[0] == "1"){
    		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
    		$menu = DB::table('d_menu')
                ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
    			->where('d_menu_lang.LANGUAGE_ID', '=', '1')
                ->select('d_menu.*', 'd_menu_lang.*')
                ->get();
    		$tabsAdjust = count($langs);
    		$tabsAdjust = 100 / $tabsAdjust;
            return view($this->prefixViewDirFiles . 'menuadd')->with(
                [
                    'langs'=> $langs,
                    'tabsajust' => $tabsAdjust,
                    'pages' => Page::where('STATUS', 1)->get(),
                    'menu' => $menu
                ]);
      }else{
        return redirect()->route('home');
      }
    }
    public function insert(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddMenu')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->get();
        $this->validation($req, $langs);
    		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

		if($req->input("status") == TRUE){
			$status = 1;
		}
		$menu = DB::table('d_menu')->insertGetId(['PARENT_ID' => $req->input("parent"), 'status' => $status, 'PAGE_ID' => $page_id, 'ORDER' => (!empty($req->input("order"))) ? $req->input("order") : "0" ]);


        foreach ($langs as $l => $lang) {
			DB::table('d_menu_lang')->insert(['MENU_ID' => $menu, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'M_NAME' => $req->input("name_{$lang->SLUG}"), 'URL' => $req->input("url_{$lang->SLUG}"), 'TITLE_SEO' => $req->input("title_seo_{$lang->SLUG}"), 'DESCRIPTION_SEO' => $req->input("description_seo_{$lang->SLUG}"), 'KEYWORDS_SEO' => $req->input("keywords_seo_{$lang->SLUG}")]);

		}

        return redirect()->route('menuList');
      }else{
        return redirect()->route('home');
      }
    }
    public function menulist(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListMenu')->pluck('PERMISSIONS')[0] == "1"){
		$menu = DB::table('d_menu')
            ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
			->where('d_menu_lang.LANGUAGE_ID', '=', '1')
			->where('d_menu.PARENT_ID', '=', '-1')
            ->select('d_menu.*', 'd_menu_lang.*')
            ->orderBy('ORDER','ASC')
            ->orderBy('d_menu.MENU_ID','ASC')
            ->get();
		foreach ($menu as $k => $m) {
			$view = DB::table('d_menu')->where('PARENT_ID','=',$m->MENU_ID)->get();
			$view2[] = count($view);
		}
		$view2[] = "";
        return view($this->prefixViewDirFiles . 'menuList')->with('menus', $menu)->with('view', $view2);
      }else{
        return redirect()->route('home');
      }
    }
    public function menuview(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListMenu')->pluck('PERMISSIONS')[0] == "1"){
		$menu = DB::table('d_menu')
            ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
			->where('d_menu_lang.LANGUAGE_ID', '=', '1')
			->where('d_menu.PARENT_ID', '=', $id)
            ->select('d_menu.*', 'd_menu_lang.*')
            ->orderBy('ORDER')
            ->get();
		foreach ($menu as $k => $m) {
			$view = DB::table('d_menu')->where('PARENT_ID','=',$m->MENU_ID)->get();
			$view2[] = count($view);
		}
		$view2[] = "";
		$getParent = DB::table('d_menu')->where('MENU_ID','=',$id)->get();
        $idCrumb = $id;
        $crumb = TRUE;
        $crumbArray = [];
        $saves_ids = [];
        while ($crumb == TRUE) {
            if ($idCrumb != -1 ) {
                $getParent2 = DB::table('d_menu')->where('MENU_ID','=',$idCrumb)->select('PARENT_ID')->get();
                array_push($saves_ids, $idCrumb);
                $idCrumb = $getParent2[0]->PARENT_ID;

            }else{
                $crumb == FALSE;
                break;
            }
        }
        if (!empty($saves_ids)) {
            foreach ($saves_ids as $key => $sid) {
                $menubreadcrumb = DB::table('d_menu')
                ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
                ->where('d_menu_lang.LANGUAGE_ID', '=', '1')
                ->where('d_menu.MENU_ID', '=', $sid)
                ->select('d_menu.*', 'd_menu_lang.*')
                ->orderBy('ORDER')
                ->get();

                array_push($crumbArray, $menubreadcrumb);

            }
        }
        $crumbArray = array_reverse($crumbArray);
        return view($this->prefixViewDirFiles . 'menuView')->with('menus', $menu)->with('view', $view2)->with('backid', $getParent)->with('breadcrumb', $crumbArray)->with('pgId', $id);
      }else{
        return redirect()->route('home');
      }
    }
	public function menuedit(Request $req, $id)
	{
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListMenu')->pluck('PERMISSIONS')[0] == "1"){
		$langs = DB::table('a_languages')
					->join('d_menu_lang', 'd_menu_lang.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
					->where('d_menu_lang.MENU_ID', '=', $id)
					->select('a_languages.*','d_menu_lang.*')
					->orderBy('STATUS', 'desc')
					->get();
		$menu = DB::table('d_menu')->select('MENU_ID', 'PARENT_ID', 'STATUS', 'PAGE_ID', 'ORDER')->where('MENU_ID', $id)->get();
		$menu2 = DB::table('d_menu')
            ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
			->where('d_menu_lang.LANGUAGE_ID', '=', '1')
            ->select('d_menu.*', 'd_menu_lang.*')
            ->get();
		$tabsajust = count($langs);
		try{
		    $tabsajust = 100 / $tabsajust;
        }catch (\Exception $e){
		    abort(404);
        }

        $getParent = DB::table('d_menu')->where('MENU_ID','=',$id)->get();
        $idCrumb = $id;
        $crumb = TRUE;
        $crumbArray = [];
        while ($crumb == TRUE) {
            if ($idCrumb != -1) {
                $getParent2 = DB::table('d_menu')->where('MENU_ID','=',$idCrumb)->select('PARENT_ID')->get();
                $idCrumb = $getParent2[0]->PARENT_ID;
                $menubreadcrumb = DB::table('d_menu')
                ->join('d_menu_lang', 'd_menu.MENU_ID', '=', 'd_menu_lang.MENU_ID')
                ->where('d_menu_lang.LANGUAGE_ID', '=', '1')
                ->where('d_menu.PARENT_ID', '=', $idCrumb)
                ->select('d_menu.*', 'd_menu_lang.*')
                ->orderBy('ORDER')
                ->get();

                array_push($crumbArray, $menubreadcrumb);

            }else{
                $crumb == FALSE;
                break;
            }
        }
        $crumbArray = array_reverse($crumbArray);

		return view($this->prefixViewDirFiles . 'menuedit')->with(
		    [
		        'langs'=> $langs,
                'pages' => Page::where('STATUS', 1)->get(),
                'tabsajust'=> $tabsajust,
                'menu2'=> $menu2,
                'idback'=> $id,
                'menu'=> $menu,
                'breadcrumb'=> $crumbArray,
                'pgId'=> $id
            ]);
    }else{
      return redirect()->route('home');
    }
	}
    public function update(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListMenu')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG','STATUS')->get();
        $this->validation($req, $langs);

		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

		if($req->input("status") == TRUE){
			$status = 1;
		}
		DB::table('d_menu')->where('MENU_ID', $id)->update(['PARENT_ID' => $req->input("parent"), 'status' => $status, 'PAGE_ID'=> $page_id, 'ORDER'=> $req->input("order")]);
		foreach ($langs as $l => $lang) {
			DB::table('d_menu_lang')->where('MENU_ID', $id)->where('LANGUAGE_ID', $lang->LANGUAGE_ID)->update(['MENU_ID' => $id, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'M_NAME' => $req->input("name_{$lang->SLUG}"), 'URL' => $req->input("url_{$lang->SLUG}"), 'TITLE_SEO' => $req->input("title_seo_{$lang->SLUG}"), 'DESCRIPTION_SEO' => $req->input("description_seo_{$lang->SLUG}"), 'KEYWORDS_SEO' => $req->input("keywords_seo_{$lang->SLUG}")]);
		}
        return redirect()->route('menuList');
      }else{
        return redirect()->route('home');
      }
    }
	public function remove(Request $req, $id) {
    if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListMenu')->pluck('PERMISSIONS')[0] == "1"){
		DB::table('d_menu')->where('MENU_ID', '=', $id)->delete();
		DB::table('d_menu_lang')->where('MENU_ID', '=', $id)->delete();
		return redirect()->route('menuList');
  }else{
    return redirect()->route('home');
  }
	}

    public function validation(Request $request, Collection $languages){


        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
            $array_of_name_langs_to_validate += ["url_{$lang->SLUG}" => 'required|max:50'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),
            ]
        );
    }
}
