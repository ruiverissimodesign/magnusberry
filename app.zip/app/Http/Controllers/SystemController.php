<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Cookie;

class SystemController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.config.';
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
	public function update(Request $req, $id, $table, $column, $prevStatus) {
      DB::table($table)->where($column,$id)->update(['STATUS'=>!$prevStatus]);
      return redirect()->back();
	}
	public function tplist(Request $req) {
    if(Auth::user()->rank == "SuperAdmin"){
      $tplist = DB::table('teamplate')->get();
			return view($this->prefixViewDirFiles . 'listTp')->with("tplist", $tplist);
    }else{
      return redirect()->route('home');
    }
	}
	public function tpremove(Request $req, $id) {
    if(Auth::user()->rank == "SuperAdmin"){
      $getFile = DB::table('teamplate')->where('ID',$id)->first();
      DB::table('teamplate')->where('ID',$id)->delete();
      if($getFile->TYPE == 'section'){$tablerm = "section";}elseif($getFile->TYPE == 'article'){$tablerm = "article";}else{$tablerm = "e_banner";}
      DB::table($tablerm)->where('TEAMPLATE',$getFile->FILE)->update(['TEAMPLATE' => 'default']);
      $command = "scrap:view frontend.teamplate.".$getFile->TYPE.".".$getFile->FILE." --force";
      if($getFile->TYPE == 'banner'){
        $commandSlide = "scrap:view frontend.teamplate.".$getFile->TYPE.".item.".$getFile->FILE." --force";
        Artisan::call($commandSlide);
      }
      Artisan::call($command);
			return redirect()->route('listTeamplates');
    }else{
      return redirect()->route('home');
    }
	}
	public function tpinsert(Request $req) {
    if(Auth::user()->rank == "SuperAdmin"){
      $file = preg_replace('/[^A-Za-z]/', "", $req->input("name"));
      $file = strtolower($file);

      $validate = $req->validate([
  	        'name'=>'required',
            [
                'required' => \Lang::get('system.edit-error-name-required')
            ]
      ]);

      DB::table('teamplate')->insert(
          ['NAME' => $req->input("name"), 'FILE' => $file, 'TYPE' => $req->input("type")]
      );
      // $command = "make:view frontend.teamplate.".$file." --extends=frontend.pages.buildPage --with-yields";
      $command = "make:view frontend.teamplate.".$req->input("type").".".$file;
      if($req->input("type") == 'banner'){
        $commandSlide = "make:view frontend.teamplate.".$req->input("type").".item.".$file;
        Artisan::call($commandSlide);
      }
      Artisan::call($command);
		return redirect()->route('listTeamplates')->withErrors($validate);
    }else{
      return redirect()->route('home');
    }
	}
	public function configindex() {
    if(Auth::user()->rank == "SuperAdmin"){
            $modulos = DB::table("modulos")->orderBy("ID","ASC")->get();
			return view($this->prefixViewDirFiles . 'index', compact('modulos'));
    }else{
      return redirect()->route('home');
    }
	}

    public function instalation(Request $request)
    {
      if(Auth::user()->rank == "SuperAdmin"){
        try{

            $directory = public_path('storage');
            File::deleteDirectory(public_path($directory));

            $storageLinkCode = Artisan::call('storage:link');
            $clearDb = Artisan::call('migrate:fresh --seed');

        }catch (\Exception $e){
            $request->session()->flash(
                'error', 'The Instalation wasn\'t Successfully. Please make sure that the directory public/storage is with right permitions.'
            );
            return redirect()->route('home');
        }
        $request->session()->flash(
            'success', 'The Instalation was Successfully.'
        );
        return redirect()->route('home');
      }else{
        return redirect()->route('home');
      }
	}
    public function cookieCreate($name,$value)
    {
        Cookie::queue(Cookie::forever($name, $value));
    }
    public function resetFrontend(Request $request)
    {
        try{
            $directory = public_path('storage');
            File::deleteDirectory(public_path($directory));

            $storageLinkCode = Artisan::call('storage:link');
            $clearDb = Artisan::call('migrate:fresh --seed');

        }catch (\Exception $e){
            $request->session()->flash(
                'error', 'The Instalation wasn\'t Successfully. Please make sure that the directory public/storage is with right permitions.'
            );
            return redirect()->route('home');
        }
        $request->session()->flash(
            'success', 'The Instalation was Successfully.'
        );
        return redirect()->route('home');
	}
    public function updateDB(Request $request)
    {
      if(Auth::user()->rank == "SuperAdmin"){
        $clearDb = Artisan::call('migrate');
        $request->session()->flash(
            'success', 'The Instalation was Successfully.'
        );
        return redirect()->route('home');
      }else{
        return redirect()->route('home');
      }
	}
    public function runCommand(Request $request)
    {

      if(Auth::user()->rank == "SuperAdmin"){
        $teste = Artisan::call($request->terminal);
        $request->session()->flash(
            'success', 'The Instalation was Successfully.'
        );
        return redirect()->route('config.index');
      }else{
        return redirect()->route('home');
      }
	}
  public function ajaxPro(Request $req, $table, $id) {
    $position = $req->input("position");
    $i=1;
    foreach($position as $k=>$v){
        DB::table($table)->where($id, $v)->update(['ORDER' => $i]);
        $i++;
    }
  }
  public function deleteAll(Request $req, $table, $id) {
    $page = $req->input("page");
    foreach($page as $k => $v){
        DB::table($table)->where($id, $v)->delete();
        if($table == "page"){
            $pagelang = DB::table('page_lang')->where('PAGE_ID', $v)->get();
            foreach ($pagelang as $p => $pglang) {
              DB::table('page_lang')->where('PAGE_ID', $pglang->PAGE_ID)->delete();
            }
        }
    }
    return \App::make('redirect')->back()->with('flash_success', 'All Select Removed');
  }

}
