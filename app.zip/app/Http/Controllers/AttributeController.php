<?php

namespace App\Http\Controllers;

use App\Attribute;
use App\AttributeName;
use App\AttributeValue;
use App\Languages;
use App\Rank;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class AttributeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDir = '';

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDir = 'backoffice.attribute.';
    }

    public function index()
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $attribute = DB::table('attribute_name')
                ->where('LANGUAGE_ID', '=', '1')
                ->get();
            return view($this->prefixViewDir.'/attributeList')->with('attribute', $attribute);
        }else{
          return redirect()->route('home');
        }
    }
    public function attributeAdd()
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
    		$tabsajust = count($langs);
    		$tabsajust = 100 / $tabsajust;
            return view($this->prefixViewDir.'attributeAdd')->with('langs', $langs)->with('tabsajust', $tabsajust);
        }else{
          return redirect()->route('home');
        }
    }
    public function attributeInsert(Request $req)
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $attribute = DB::table('attribute')->insertGetId([]);
            $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG')->get();
            foreach ($langs as $l => $lang) {
    			DB::table('attribute_name')->insert(['ATTRIBUTE_ID' => $attribute, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'A_NAME' => $req->input("name_{$lang->SLUG}")]);
    		}
            return redirect()->route('attributeList');
        }else{
          return redirect()->route('home');
        }
    }
    public function attributeEdit($id)
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $langs = DB::table('a_languages')
    					->join('attribute_name', 'attribute_name.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
    					->where('attribute_name.ATTRIBUTE_ID', '=', $id)
    					->select('a_languages.*','attribute_name.*')
    					->orderBy('STATUS', 'desc')
    					->get();
            // $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
            $tabsajust = count($langs);
            $tabsajust = 100 / $tabsajust;
            return view($this->prefixViewDir.'attributeEdit')->with('langs', $langs)->with('tabsajust', $tabsajust)->with('id',$id);
        }else{
            return redirect()->route('home');
        }
    }
    public function attributeUpdate(Request $req, $id)
    {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG')->get();
            foreach ($langs as $l => $lang) {
                DB::table('attribute_name')->where('ATTRIBUTE_ID', $id)->where('LANGUAGE_ID', $lang->LANGUAGE_ID)->update(['ATTRIBUTE_ID' => $id, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'A_NAME' => $req->input("name_{$lang->SLUG}")]);
            }
            return redirect()->route('attributeList');
        }else{
            return redirect()->route('home');
        }
    }
	public function attributeRemove ($id){
		if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
	        DB::table('attribute')->where('ATTRIBUTE_ID', $id)->delete();
	        DB::table('attribute_name')->where('ATTRIBUTE_ID', $id)->delete();
	        DB::table('attribute_value')->where('ATTRIBUTE_ID', $id)->delete();
	        DB::table('attribute_product')->where('ATTRIBUTE_ID', $id)->delete();
			return redirect()->route('attributeList');
		}else{
			return redirect()->route('home');
		}
    }

	public function attributeValueList($id)
	{
		if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
			$values = DB::table('attribute_value')
				->where('LANGUAGE_ID', '=', '1')
				->where('attribute_value.ATTRIBUTE_ID', '=', $id)
				->get();
            $parent = DB::table('attribute_name')
				->where('LANGUAGE_ID', '=', '1')
				->where('attribute_name.ATTRIBUTE_ID', '=', $id)
				->get();
			$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
			$tabsajust = count($langs);
			$tabsajust = 100 / $tabsajust;
            return view($this->prefixViewDir.'/attributeValueList')
                ->with('value', $values)
                ->with('parent', $parent)
                ->with('langs', $langs)
                ->with('id',$id)
                ->with('tabsajust', $tabsajust);
		}else{
		  return redirect()->route('home');
		}
	}
	public function attributeValueAdd(Request $req, $id) {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->get();
        $this->validation($req, $langs);
    	$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;
		if($req->input("status") == TRUE){
			$status = 1;
		}
        foreach ($langs as $l => $lang) {
			if ($l == 0 ) {
				$idFather = DB::table('attribute_value')->insertGetId(['ATTRIBUTE_ID' => $id, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'A_VALUE' => $req->input("name_{$lang->SLUG}")]);
				DB::table('attribute_value')->where('ATTRIBUTE_VALUE_LANG_ID', $idFather)->update(['ATTRIBUTE_VALUE_ID' => $idFather]);
			} else {
				DB::table('attribute_value')->insert(['ATTRIBUTE_ID' => $id, 'LANGUAGE_ID' => $lang->LANGUAGE_ID, 'A_VALUE' => $req->input("name_{$lang->SLUG}"), 'ATTRIBUTE_VALUE_ID' => $idFather]);
			}
		}
        return redirect()->route('attributeValueList',$id);
      }else{
        return redirect()->route('home');
      }
    }
	public function attributeValueEdit(Request $req, $id) {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')
              ->join('attribute_value', 'attribute_value.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
              ->where('attribute_value.ATTRIBUTE_VALUE_ID', '=', $id)
              ->select('a_languages.*','attribute_value.*')
              ->orderBy('STATUS', 'desc')
              ->get();
        $parent_name = DB::table('attribute_name')
            ->where('LANGUAGE_ID', '=', '1')
            ->where('ATTRIBUTE_ID', '=', $langs[0]->ATTRIBUTE_ID)
            ->get();
        $tabsajust = count($langs);
        $tabsajust = 100 / $tabsajust;
        return view($this->prefixViewDir.'attributeValueEdit')->with('langs', $langs)->with('tabsajust', $tabsajust)->with('id',$id)->with('parentName',$parent_name);

        return redirect()->route('attributeValueEdit',$id);
      }else{
        return redirect()->route('home');
      }
    }
	public function attributeValueUpdate(Request $req, $id) {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $langs = DB::table('a_languages')
                  ->join('attribute_value', 'attribute_value.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
                  ->where('attribute_value.ATTRIBUTE_VALUE_ID', '=', $id)
                  ->select('a_languages.*','attribute_value.*')
                  ->orderBy('STATUS', 'desc')
                  ->get();
            foreach ($langs as $l => $lang) {
                DB::table('attribute_value')->where('ATTRIBUTE_VALUE_ID', $id)->where('LANGUAGE_ID', $lang->LANGUAGE_ID)->update(['ATTRIBUTE_ID' => $lang->ATTRIBUTE_ID, 'LANGUAGE_ID' => $lang->LANGUAGE_ID,'ATTRIBUTE_VALUE_ID' => $lang->ATTRIBUTE_VALUE_ID, 'A_VALUE' => $req->input("name_{$lang->SLUG}")]);
            }
            return redirect()->route('attributeValueList',$langs[0]->ATTRIBUTE_ID);
        }else{
            return redirect()->route('home');
        }
    }

    public function attributeValueRemove ($id){
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $back = DB::table('attribute_value')->where('ATTRIBUTE_VALUE_ID', $id)->first();
            DB::table('attribute_value')->where('ATTRIBUTE_VALUE_ID', $id)->delete();
            return redirect()->route('attributeValueList', $back->ATTRIBUTE_ID);
        }else{
            return redirect()->route('home');
        }
    }

	public function validation(Request $request, Collection $languages){
        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:1|max:50'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),
            ]
        );
    }



}
