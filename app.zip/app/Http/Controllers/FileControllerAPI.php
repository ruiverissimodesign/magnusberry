<?php

namespace App\Http\Controllers;

use App\File;
use App\ArticleFile;
use App\ProductFile;
use App\ProductCategoryFile;
use App\SectionFile;
use App\BannerItem;
use App\BannerItemLang;
use App\FileLang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use App\Http\Controllers\FileController;
use App\Rank;
use Auth;

class FileControllerAPI extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json(File::all(), 200)
                    ->header('Content-Type', 'application/json');
    }

    public function pagination( Request $request) {

        return response()
                ->json(File::orderBy('created_at', 'desc')->paginate(25), 200)
                ->header('Content-Type', 'application/json');

    }


    public function getFileById($id)
    {

        $file = File::where('FILE_ID', $id)->first();
        if($file){
            return response()->json($file, 200)
                ->header('Content-Type', 'application/json');
        }
        else{
            return response()->json(['message' => 'File Not Found'], 404)
                ->header('Content-Type', 'application/json');
        }

    }
    public function destroyFile($id)
    {
        //Find the file

        $file = File::findOrFail($id);

        //Delete the original one (EVERY FILE AS A ORIGINAL)
        Storage::delete('files/original/' . $file->FILE);

        //If the file is of one of those types, Remove them from others dirs
        if (
        FileController::isFileAImage($file->TYPE)
        ){
            Storage::delete([
                'files/small/' .  $file->FILE,
                'files/medium/' .  $file->FILE,

            ]);
        }

        //Eliminar traduções
        $trads = FileLang::where('FILE_ID', $file->FILE_ID)->get();

        foreach ($trads as $trad) {
            $trad->delete();
        }
        //Eliminar Articles Files
        $artcs = ArticleFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($artcs)){
          foreach ($artcs as $artc) {
            $artc->delete();
          }
        }
        $prods = ProductFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($prods)){
          foreach ($prods as $prod) {
            $prod->delete();
          }
        }
        $prodCats = ProductCategoryFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($prodCats)){
          foreach ($prodCats as $prodCat) {
            $prodCat->delete();
          }
        }
        $slides = BannerItem::where('IMG_ID', $file->FILE_ID)->get();
        if(!empty($slides)){
          foreach ($slides as $slide) {
            $slide->delete();
            $slidesLang = BannerItemLang::where('BANNER_ITEM_ID', $slide->BANNER_ITEM_ID)->get();
            foreach ($slidesLang as $slideLang) {
              $slideLang->delete();
            }
          }
        }
        //Eliminar Section Files
        $setcs = SectionFile::where('FILE_ID', $file->FILE_ID)->get();
        if(!empty($setcs)){
          foreach ($setcs as $setc) {
              $setc->delete();
          }
        }
        $file->delete();



        return response()->json(['message'=> 'The file was deleted successfully'], 200);



    }

    /**
     * This endpoint gets a id and a image data (base64 encoded)
     *
     * @param API id The id of a file that will be changed (actually nothing is changed
     *  in the file, but the value of the $file->FILE is used to save the crop image to the crop dir
     * )
     *
     * @param API imageData base64 encoded image string
     * @return Array
     */
    public function crop() {
        $file = \App\File::findOrFail((int) Input::get('imageId'));
        $filenametostore = $file->FILE;
        $image = Input::get('imageData');

        //Creates a empty file
        \Storage::put('files/original/'. $filenametostore, '');

        //Gets the path of that file
        $pathOriginal = public_path('storage/files/original/' . $file->FILE);
        $pathOriginal = str_replace('/', '\\', $pathOriginal);

        $pathSmall = public_path('storage/files/small/' . $file->FILE);
        $pathSmall = str_replace('/', '\\', $pathSmall);

        $pathMedium = public_path('storage/files/medium/' . $file->FILE);
        $pathMedium = str_replace('/', '\\', $pathMedium);

        //Write the base64 data to the file
        Image::make(base64_decode($image))
                ->save($pathOriginal)
                ->save($pathSmall)
                ->save($pathMedium);

        //Resize images
        //We only need to copy that image from original to the others files


        FileController::createDifferentSizeImages($filenametostore);

        return response()->json([
            'message' => 'Everything went good'
        ], 200);


    }
}
