<?php

namespace App\Http\Controllers;

use App\Article;
use App\Menu;
use App\Section;
use App\Category;
use App\Product;
use App\Languages;
use App\SectionFile;
use App\SectionLang;
use App\SectionArticle;
use App\SectionProduct;
use App\ProductCategory;

use App\SectionPage;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Log;
use App\Rank;
use Auth;

class SectionController extends Controller
{


    /**
     * @var string
     */
    private $prefixViewDirFiles;

    function __construct(){
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.section.';
    }

    public function index()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        return view($this->prefixViewDirFiles . 'index')->withSections(Section::all());
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSection')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;

        // Slideshow
		$slideshows = DB::table('e_banner')->get();
        Log::info($slideshows);

        // ARTICLES
        $articles = Article::where('STATUS', 1)->get();
        Log::info($articles);

         // Categories
         $categories = Category::where('STATUS', 1)->get();
         Log::info($categories);

         // Products
         $products = DB::table('product')
             ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
             ->where('product_lang.LANGUAGE_ID', '=', '1')
             ->select('product.*', 'product_lang.*')
             ->get();
         Log::info($products);

         $teamplates = DB::table('teamplate')->where('TYPE','section')->get();
         Log::info($teamplates);

        return view($this->prefixViewDirFiles . 'create')
                ->with([
                    'tabsAdjust'   => $tabsAdjust,
                    'languages'    => $languages,
                    'slideshows'   => $slideshows,
                    'articles'     => $articles,
                    'categories'   => $categories,
                    'products'   => $products,
                    'teamplates'   => $teamplates,

                    ]);

      }else{
        return redirect()->route('home');
      }
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function replicate($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        $section_replicate = Section::findOrFail($id);
        $section = $section_replicate->replicate();
        $section->save();

        if(SectionLang::where('SECTION_ID', $section_replicate->SECTION_ID)){
            foreach (SectionLang::where('SECTION_ID', $section_replicate->SECTION_ID)->get() as $section_replicate_replicate) {
                $section_lang = $section_replicate_replicate->replicate();
                $section_lang->SECTION_ID = $section->SECTION_ID;
                $section_lang->save();
            }
        }


        foreach (SectionFile::where('SECTION_ID', $section_replicate->SECTION_ID)->get() as $section_file_replicate) {
            $section_file = $section_file_replicate->replicate();
            $section_file->SECTION_ID = $section->SECTION_ID;
            $section_file->save();
        }

        foreach (SectionArticle::where('SECTION_ID', $section_replicate->SECTION_ID)->get() as $section_articles) {
            $new = $section_articles->replicate();
            $new->SECTION_ID = $section->SECTION_ID;
            $new->save();
        }

        foreach (SectionProduct::where('SECTION_ID', $section_replicate->SECTION_ID)->get() as $section_product) {
            $new = $section_product->replicate();
            $new->SECTION_ID = $section->SECTION_ID;
            $new->save();
        }


        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $section_file = SectionFile::where('SECTION_ID', $section->SECTION_ID)->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;


        // dd([
        //     $article, $article_lang, $article_file
        // ]);
        $slideshows = DB::table('e_banner')->get();
        Log::info($slideshows);

        // ARTICLES
        $articles = Article::where('STATUS', 1)->get();
        Log::info($articles);

        // Categories
        $categories = Category::where('STATUS', 1)->get();
        Log::info($categories);

        $categories_product = ProductCategory::where('C_PARENT_ID', -1)->where('STATUS', 1)->get();
        Log::info($categories_product);

        // Products
        $products = DB::table('product')
            ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
            ->where('product_lang.LANGUAGE_ID', '=', '1')
            ->select('product.*', 'product_lang.*')
            ->get();
        Log::info($products);

        $teamplates = DB::table('teamplate')->where('TYPE','section')->get();
        Log::info($teamplates);

        return view($this->prefixViewDirFiles . 'edit')->with([
            'section' => $section,
            'tabsAdjust' => $tabsAdjust,
            'languages' => $languages,
            'section_file' => $section_file,
            'slideshows'   => $slideshows,
            'articles'     => $articles,
            'categories'   => $categories,
            'categories_product'   => $categories_product,
            'id'   => $id,
            'products'   => $products,
            'teamplates'   => $teamplates,
            'pathBack' => route('section.index')
            ]);

      }else{
        return redirect()->route('home');
      }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddSection')->pluck('PERMISSIONS')[0] == "1"){

        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $this->validation($request, $languages);


        $section = new Section();
        $this->defaultSectionCamps($request, $section);

        // TRADÇOES
        foreach ($languages as $lang) {
            $section_lang = new SectionLang();


            $this->defaultSectionLanguageCamps($request, $section, $section_lang, $lang);

        }

        // FILES
        if($request->input("image_code")){
            $index = 1;
            foreach($request->input("image_code") as $image_id => $image_code){
                $section_file = new SectionFile();
                $this->defaultSectionFileCamps($section, $section_file, $index, $image_id, $image_code);
                $index++;
            }
        }

        $this->customCamps($request, $section);
        //IMPLEMENT LOGIC FOR DEPENDING ON THE FYLE TYPE
        $this->defaultSectionTypes($request, $section);


        $request->session()->flash('status', \Lang::get('section.created'));

        return back();
      }else{
        return redirect()->route('home');
      }

    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, $pathBack = null)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        if(!$pathBack){
            $pathBack = route('section.index');
        }
        $section = Section::findOrFail($id);
        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $section_file = SectionFile::where('SECTION_ID', $section->SECTION_ID)->orderby('ORDER','ASC')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;


        $slideshows = DB::table('e_banner')->get();
        Log::info($slideshows);

        // ARTICLES
        $articles = Article::where('STATUS', 1)->get();
        Log::info($articles);

         // Categories
         $categories = Category::where('STATUS', 1)->get();
         Log::info($categories);

         $categories_product = ProductCategory::where('C_PARENT_ID', -1)->where('STATUS', 1)->get();
         Log::info($categories_product);

         // Products
         $products = DB::table('product')
             ->join('product_lang', 'product.PRODUCT_ID', '=', 'product_lang.PRODUCT_ID')
             ->where('product_lang.LANGUAGE_ID', '=', '1')
             ->select('product.*', 'product_lang.*')
             ->get();
         Log::info($products);

         $teamplates = DB::table('teamplate')->where('TYPE','section')->get();
         Log::info($teamplates);
        return view($this->prefixViewDirFiles . 'edit')->with([
            'section' => $section,
            'tabsAdjust' => $tabsAdjust,
            'languages' => $languages,
            'section_file' => $section_file,
            'slideshows'   => $slideshows,
            'articles'     => $articles,
            'categories'   => $categories,
            'categories_product'   => $categories_product,
            'id'   => $id,
            'products'   => $products,
            'teamplates'   => $teamplates,
            'pathBack' => $pathBack
        ]);
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $this->validation($request, $languages);

        $section = Section::findOrFail($id);
        $this->defaultSectionCamps($request, $section);


        foreach ($languages as $lang) {
            $section_lang = SectionLang::firstOrCreate(['SECTION_ID' => $section->SECTION_ID, 'LANGUAGE_ID' => $lang->LANGUAGE_ID]);
            $this->defaultSectionLanguageCamps($request, $section, $section_lang, $lang);
        }
        foreach (SectionFile::where('SECTION_ID', $section->SECTION_ID)->get() as $value) {
            $value->delete();
        }
        if($request->input("image_code")){
            $index=1;
            foreach($request->input("image_code") as $image_id => $image_code){
                $section_file = new SectionFile();
                $this->defaultSectionFileCamps($section, $section_file, $index, $image_id, $image_code);
                $index++;
            }
        }
        $this->defaultSectionTypes($request, $section);

        $this->customCamps2($request, $section);

        $request->session()->flash('status', \Lang::get('section.updated'));

        return redirect()->route('section.index');

      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        foreach(SectionArticle::where('SECTION_ID', $id)->get() as $article_section){
            $article_section->delete();
        }
        foreach(SectionFile::where('SECTION_ID', $id)->get() as $file){
            $file->delete();
        }
        foreach(SectionPage::where('SECTION_ID', $id)->get() as $section_page){
            $section_page->delete();
        }

        Section::findOrFail($id)->delete();

        $request->session()->flash('alert-success', Lang::get('section.removeSection-success'));
        return redirect()->route('section.index');

      }else{
        return redirect()->route('home');
      }
    }

    /**
     * @description Set the default camps
     * @param Request $request
     * @param $section
     */
    public function defaultSectionCamps(Request $request, $section) {
        $section->ORDERBY = $request->input('order_by') ? $request->input('order_by') : ""; // if it has a value assign it else put a 0

        $section->DESTAQUE = $request->input('destaque') === 'on' ? 1 : 0;
        $section->STATUS = $request->input('status')  === 'on' ? 1 : 0;
        $section->LIMIT = $request->input('limit') ? $request->input('limit') : 0; // if it has a value assign it else put a 0
        $section->TYPE = $request->input('select_type');
        $section->TEAMPLATE = $request->input('select_tp');
        $section->save();
    }


    public function defaultSectionLanguageCamps(Request $request, $section, $section_lang, $lang){
        $section_lang->LANGUAGE_ID = $lang->LANGUAGE_ID;
        $section_lang->SECTION_ID = $section->SECTION_ID;

        $section_lang->NAME_SEO = $request->input("name_{$lang->SLUG}");
        $section_lang->TEXT_SEO = $request->input("text_{$lang->SLUG}");
        $section_lang->save();

    }


    public function defaultSectionFileCamps( $section, $section_file, $order, $image_id, $image_code ){

        $section_file->SECTION_ID = $section->SECTION_ID;
        $section_file->FILE_ID = $image_id;
        $section_file->CODE = $image_code === null ? '' : $image_code;
        $section_file->ORDER = $order;
        $section_file->save();
    }

    public function defaultSectionTypes(Request $request, $section){
        switch ($request->input('select_type')) {
            case 'section':
                // let itemid blank
                break;
            case 'slideshow':
                $section->ITEMID = $request->input('slideshow');
                break;
            case 'article':
                $section->ITEMID = $request->input('select_article');
                break;
            case 'grouparticles':
                DB::table('section_article')->where('SECTION_ID',$section->SECTION_ID)->delete();
                if ($request->input('select_articles')) {
                    foreach ($request->input('select_articles') as $key => $articleId) {
                        $section_article = SectionArticle::firstOrCreate(['SECTION_ID'=> $section->SECTION_ID, 'ARTICLE_ID' => $articleId]);
                        $section_article->ARTICLE_ID = $articleId;
                        $section_article->SECTION_ID = $section->SECTION_ID;
                    }
                }
                break;
            case 'categories':
                $section->ITEMID = $request->input('category');
                break;
            case 'product-categories':
                $section->ITEMID = $request->input('prodcategory');
                break;
            case 'products':
                DB::table('section_product')->where('SECTION_ID',$section->SECTION_ID)->delete();
                if($request->input('select_products')){
                    foreach ($request->input('select_products') as $key => $productId) {
                        $section_product = SectionProduct::firstOrCreate(['SECTION_ID'=> $section->SECTION_ID, 'PRODUCT_ID' => $productId]);
                        $section_product->PRODUCT_ID = $productId;
                        $section_product->SECTION_ID = $section->SECTION_ID;
                    }
                }
                break;
        }

        $section->save();

    }

    public function customCamps(Request $request, $section){


        if(!$request->input('custom_camps')) {
            return;
        }
        $custom_camps = '{';

        foreach($request->input('custom_camps') as $key => $custom_camp){
            if(!empty($custom_camp['key'])){
                $custom_camps .= '"' . $custom_camp['key'] . '":"' . $custom_camp['value'] . '"';
                if (!($key === array_key_last($request->input('custom_camps')))){
                    $custom_camps .= ',';
                }
            }
        }
        $custom_camps .= '}';

        $section->CUSTOMCAMPS = $custom_camps;
        $section->save();
    }
    public function customCamps2(Request $request, $section){
        function merge($a1, $a2) {
            $aRes = $a1;
            foreach ( array_slice ( func_get_args (), 1 ) as $aRay ) {
                foreach ( array_intersect_key ( $aRay, $aRes ) as $key => $val )
                    $aRes [$key] += $val;
                $aRes += $aRay;
            }
            return $aRes;
        }

        if(!$request->input('custom_camps')) {
            return;
        }
        $custom_camps = '{';

        foreach($request->input('custom_camps') as $key => $custom_camp){
            if(!empty($custom_camp['key'])){
                $custom_camps .= '"' . $custom_camp['key'] . '":"' . $custom_camp['value'] . '"';
                if (!($key === array_key_last($request->input('custom_camps')))){
                    $custom_camps .= ',';
                }
            }
        }
        $custom_camps .= '}';
        if(empty($request->custom_camp)){
            $section->CUSTOMCAMPS = $custom_camps;
        }elseif (empty($custom_camps)) {
            $section->CUSTOMCAMPS = $request->custom_camp;
        }else{
            $section->CUSTOMCAMPS = json_encode(merge($request->custom_camp,json_decode($custom_camps, true)));
        }

        $section->save();
    }

    public function disassociate(Request $request, $section_id,$article_id)
    {
        SectionArticle::where(['SECTION_ID' => $section_id, 'ARTICLE_ID' => $article_id])->delete();
        $request->session()->flash('status', 'Article was dissassociate successfully');
        return back();
    }
    public function disassociateproduct(Request $request, $section_id,$product_id)
    {
        SectionProduct::where(['SECTION_ID' => $section_id, 'PRODUCT_ID' => $product_id])->delete();
        $request->session()->flash('status', 'Product was dissassociate successfully');
        return back();
    }
    public function show($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListSection')->pluck('PERMISSIONS')[0] == "1"){
        $section = Section::findOrFail($id);
        $section_lang = SectionLang::where(['SECTION_ID' => $section->SECTION_ID])->first();
        $articles = [];
        foreach(SectionArticle::where(['SECTION_ID' => $section->SECTION_ID])->get() as $section_article){
            $articles[] = Article::find($section_article->ARTICLE_ID);
        }
        $products = [];
        foreach(SectionProduct::where(['SECTION_ID' => $section->SECTION_ID])->get() as $section_product){
            $products[] = Product::find($section_product->PRODUCT_ID);
        }
        return view($this->prefixViewDirFiles . 'show', compact('section', 'section_lang', 'articles', 'products'));
      }else{
        return redirect()->route('home');
      }
    }
    /**
     * @param Request $request
     * @param Collection $languages
     * @return mixed
     */
    public function validation(Request $request, Collection $languages){


        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if ($lang->STATUS == "1") {
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),

            ]
        );
    }
}
