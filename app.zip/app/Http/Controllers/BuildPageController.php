<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App;
use Session;
use Mail;
use Crico;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class BuildPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req, $pagina)
    {
      $error = "";$menuInfo = "";$language = "";
      $config = DB::table("a_company")->first();
      $menu = DB::table("d_menu_lang")->where("URL",$pagina)->get();
      if(count($menu) == 1){
      	$menuAllLang = DB::table("d_menu_lang")->where("MENU_ID",$menu[0]->MENU_ID)->orderBy("LANGUAGE_ID","ASC")->get();
        $menus_lang = DB::table("d_menu_lang")->join("d_menu","d_menu_lang.MENU_ID","=","d_menu.MENU_ID")->where("d_menu_lang.LANGUAGE_ID","=",$menu[0]->LANGUAGE_ID)->where("d_menu.STATUS","=","1")->orderBy("ORDER","ASC")->get();
        $menus = DB::table("d_menu")->orderBy("ORDER","ASC")->get();
        $language = DB::table("a_languages")->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
        $allLanguages = DB::table("a_languages")->where("STATUS",1)->get();
        $lg_s = $language->LANGUAGE_ID;
        $lg = strtolower($language->SLUG);
        Session::put('locale',$lg);
        $lang = Session::get('locale');
        App::setLocale($lang);
        $menuInfo = DB::table("d_menu")->where("MENU_ID",$menu[0]->MENU_ID)->first();
        $pageStatus = DB::table("page")->where("PAGE_ID",$menuInfo->PAGE_ID)->where("STATUS","1")->first();
        if($menuInfo->PAGE_ID == "-1" || empty($pageStatus)){
          $error = "This page is not associated";
        }else{
          $getPage = DB::table("page_lang")->where("PAGE_ID",$menuInfo->PAGE_ID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->get();
          $getSectionRelated = DB::table("section_page")->where("PAGE_ID",$menuInfo->PAGE_ID)->orderBy("ORDER","ASC")->get();
          $getSection = [];
          $getSectionFile = [];
          $teamplate = "";
          foreach ($getSectionRelated as $p => $page) {

            $getSection[$p] = DB::table("section")->where("SECTION_ID",$page->SECTION_ID)->first();
            $getSectionLang[$p] = DB::table("section_lang")->where("SECTION_ID",$page->SECTION_ID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
            $getSectionFile[$p] = DB::table("section_file")->where("SECTION_ID",$page->SECTION_ID)->get();
            foreach ($getSectionFile[$p] as $r => $filess) {
              $getSectionFiles[$p][$r] = DB::table("files")->where("FILE_ID",$filess->FILE_ID)->first();
            }
            $custom_camp = json_decode($getSection[$p]->CUSTOMCAMPS);
            $limit = ($getSection[$p]->LIMIT > 0) ? $getSection[$p]->LIMIT : NULL;
            $orderex = explode(" ",$getSection[$p]->ORDERBY);
            $orderby = (!empty($getSection[$p]->ORDERBY)) ? $orderex[0] : "ORDER";
            $order = (!empty($getSection[$p]->ORDERBY)) ? $orderex[1] : "ASC";
            $teamplateAss = "";
            $cat = "";
            if ($getSection[$p]->TEAMPLATE == "productsectionmagnus") {
                $cat = Crico::getMainCategories($lg_s);
            }elseif($getSection[$p]->TYPE != 'section'){
                if($getSection[$p]->TYPE == "grouparticles"){
                $getSectionArticle[$p] = DB::table("section_article")->where("SECTION_ID",$page->SECTION_ID)->limit($limit)->orderBy($orderby,$order)->get();
                foreach ($getSectionArticle[$p] as $a => $sa) {
                  $getArticles[$p][$a] = DB::table("article")->where("ARTICLE_ID",$sa->ARTICLE_ID)->first();
                  $getArticlesLang[$p][$a] = DB::table("article_lang")->where("ARTICLE_ID",$sa->ARTICLE_ID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
                  $getArticlesFilesCount[$p][$a] = DB::table("article_file")->where("ARTICLE_ID",$sa->ARTICLE_ID)->get();
                  $getArticlesFiles[$p][$a] = [];
                  foreach ($getArticlesFilesCount[$p][$a] as $f => $files) {
                    $getArticlesFiles[$p][$a][$f] = DB::table("files")->where("FILE_ID",$files->FILE_ID)->first();
                  }
                  $teamplateAss .= view('frontend.teamplate.article.'.$getArticles[$p][$a]->TEAMPLATE, ["article_lang" => $getArticlesLang[$p][$a], "articles_files" => $getArticlesFiles[$p][$a]])->render();
                }
              }elseif ($getSection[$p]->TYPE == "article"){
                  $getArticle[$p] = DB::table("article")->where("ARTICLE_ID",$getSection[$p]->ITEMID)->first();
                  $getArticleLang[$p] = DB::table("article_lang")->where("ARTICLE_ID",$getSection[$p]->ITEMID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
                  $getArticlesFilesCount[$p] = DB::table("article_file")->where("ARTICLE_ID",$getSection[$p]->ITEMID)->get();
                  $getArticlesFiles[$p] = [];
                  foreach ($getArticlesFilesCount[$p] as $f => $files) {
                    $getArticlesFiles[$p][$f] = DB::table("files")->where("FILE_ID",$files->FILE_ID)->first();
                  }
                  $teamplateAss = view('frontend.teamplate.article.'.$getArticle[$p]->TEAMPLATE, ["article_lang" => $getArticleLang[$p],"articles_files" => $getArticlesFiles[$p]])->render();
              }elseif ($getSection[$p]->TYPE == "categories"){
                  $countArticle[$p] = DB::table("article")->where("CATEGORY",$getSection[$p]->ITEMID)->limit($limit)->orderBy($orderby,$order)->get();
                  foreach ($countArticle[$p] as $r => $art) {
                    $getArticles[$p][$r] = DB::table("article")->where("ARTICLE_ID",$art->ARTICLE_ID)->first();
                    $getArticlesLang[$p][$r] = DB::table("article_lang")->where("ARTICLE_ID",$art->ARTICLE_ID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
                    $getArticlesFilesCount[$p][$r] = DB::table("article_file")->where("ARTICLE_ID",$art->ARTICLE_ID)->get();
                    $getArticlesFiles[$p][$r] = [];
                    foreach ($getArticlesFilesCount[$p][$r] as $f => $files) {
                      $getArticlesFiles[$p][$r][$f] = DB::table("files")->where("FILE_ID",$files->FILE_ID)->first();
                    }
                    $teamplateAss .= view('frontend.teamplate.article.'.$getArticles[$p][$r]->TEAMPLATE, ["article_lang" => $getArticlesLang[$p][$r], "articles_files" => $getArticlesFiles[$p][$r], "index" => sprintf('%02d', $r+1)])->render();
                  }
              }elseif ($getSection[$p]->TYPE == "slideshow"){
                  $getBanner[$p] = DB::table("e_banner")->where("BANNER_ID",$getSection[$p]->ITEMID)->first();
                  $countBanner[$p] = DB::table("e_banner_item")->where("BANNER_ID",$getSection[$p]->ITEMID)->limit($limit)->orderBy($orderby,$order)->get();
                  $teamplateAssItem = "";
                  foreach ($countBanner[$p] as $b => $banner) {
        					  if(count($countBanner[$p])  == ($b + 1)) {
        						  $next = 1;
        					  } else {
        						  $next = $b + 2;
        					  }
                    $getBanners[$p][$b] = DB::table("e_banner_item")->where("BANNER_ITEM_ID",$banner->BANNER_ITEM_ID)->first();
                    $getBannersLang[$p][$b] = DB::table("e_banner_item_lang")->where("BANNER_ITEM_ID",$getBanners[$p][$b]->BANNER_ITEM_ID)->where("LANGUAGE_ID",$menu[0]->LANGUAGE_ID)->first();
                    $getBannerImg[$p][$b] = DB::table("files")->where("FILE_ID",$banner->IMG_ID)->first();
                    $teamplateAssItem .= view('frontend.teamplate.banner.item.'.$getBanner[$p]->TEAMPLATE, ["banner_lang" => $getBannersLang[$p][$b], "banner" => $getBanners[$p][$b], "banner_img" => $getBannerImg[$p][$b],"id"=>($b+1),"next_no"=>($next)])->render();
                  }
                  $teamplateAss = view('frontend.teamplate.banner.'.$getBanner[$p]->TEAMPLATE, ["teamplate" => $teamplateAssItem])->render();
              } elseif ($getSection[$p]->TYPE == "product-categories"){

                $cat = Crico::getProductCategoryById($getSection[$p]->ITEMID,$lg_s);
                // $products = Crico::getProductsPage($cat->ID,$lg_s,18);
                // $teamplate .= view('frontend.teamplate.section.'.$getSection[$p]->TEAMPLATE, ["cat" => $cat,"section_lang" => (!empty($getSectionLang[$p])) ? $getSectionLang[$p]: ""])->render();
                // $teamplate .= view('frontend.teamplate.section.'.$getSection[$p]->TEAMPLATE, ["cat" => $cat, "id" => $id, "products" => $products, 'pagina'=> (!empty($pagina)) ? $pagina : ""])->render();
              }
            }
            $teamplate .= view('frontend.teamplate.section.'.$getSection[$p]->TEAMPLATE, [
		            "section_lang" => (!empty($getSectionLang[$p])) ? $getSectionLang[$p]: "",
                    "section_files" => (!empty($getSectionFiles[$p])) ? $getSectionFiles[$p] : "",
    				"section"=>(!empty($getSection[$p])) ? $getSection[$p] : "",
    				"languages" =>(!empty($allLanguages)) ? $allLanguages: "",
    				"teamplate" => (!empty($teamplateAss)) ? $teamplateAss: "",
    				"lg" => (!empty($lg)) ? $lg: "",
    				"lg_s" => (!empty($lg_s)) ? $lg_s: "",
    				"custom_camp" => (!empty($custom_camp)) ? $custom_camp: "",
    				"pageWhereIm" => (!empty($menuInfo)) ? $menuInfo : "",
    				"cat" => (!empty($cat)) ? $cat : ""
    				])->render();
          }
        }
      }elseif(count($menu) == 0){
        $error = "This page not exist";
      }else{
        $error = "This page is replicated";
      }
      // dd($menuInfo);
      return view("frontend.pages.buildPage")->with([
          'config' => (!empty($config)) ? $config : "",
          'error' => (!empty($error)) ? $error : "",
          'menu' => (!empty($menu[0])) ? $menu[0] : "",
          'menuInfo' => (!empty($menuInfo)) ? $menuInfo : "",
          'page' => (!empty($getPage)) ? $getPage : "",
          'sections' => (!empty($getSection)) ? $getSection : "",
          'sectionsLang' => (!empty($getSectionLang)) ? $getSectionLang : "",
          'sectionsFile' => (!empty($getSectionFile)) ? $getSectionFile : "",
          'language'=> (!empty($language)) ? $language : "",
          'teamplate'=> (!empty($teamplate)) ? $teamplate : "",
          'menus_lang'=> (!empty($menus_lang)) ? $menus_lang : "",
          'menus'=> (!empty($menus)) ? $menus : "",
          'menuAllLang'=> (!empty($menuAllLang)) ? $menuAllLang : "",
          'pagina'=> (!empty($pagina)) ? $pagina : "",
          'lg'=> (!empty($lg)) ? $lg : "",
          'lg_s'=> (!empty($lg_s)) ? $lg_s : "",
      ]);
    }
    public function dump($args = null){
      print "<!--\n";
  		var_dump($args);
  		print "\n-->";
    }
    public function resetFrontend(Request $request)
    {
        try{
            $directory = public_path('storage');
            File::deleteDirectory(public_path($directory));

            $storageLinkCode = Artisan::call('storage:link');
            $clearDb = Artisan::call('migrate:fresh --seed');

        }catch (\Exception $e){
            $request->session()->flash(
                'error', 'The Instalation wasn\'t Successfully. Please make sure that the directory public/storage is with right permitions.'
            );
            return redirect()->route('home');
        }
        $request->session()->flash(
            'success', 'The Instalation was Successfully.'
        );
        return redirect()->route('home');
	}
    public function contactForm(Request $request){
		$config = DB::table("a_company")->first();
	    $toReturn = [
    		"status" => false,
    		"message" => ""
    	];
      $google_secret_key = "6LfHe-UUAAAAADKPdXKg_l6h-4Vw28WceSTK-tfT";
      $google_key = $request->input('g-recaptcha-response');
      $google_response = json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$google_secret_key}&response={$google_key}"), true);
      if($google_response["success"]){
        		$data = array('color' => "#EBEBEB",
        			'logo' => url('/storage/company/'.$config->LOGO),
        			'name' => $request->input('name'),
        			'subject' => $request->input('subject'),
        			'email' => $request->input('email'),
        			'phone' => $request->input('phone'),
        			'message' => $request->input('message')
        		);

        		Mail::send('frontend.layouts.emails.contactForm',[ 'data' => $data ], function($message){
        				$config = DB::table("a_company")->first();
        				$message->from(config('mail.from.address'), config('mail.from.name'));
        				$message->to(config('mail.to'))->subject('Formulário Website');
        			});
        		if(count(Mail::failures()) > 0) {
        			$toReturn["status"] = false;
        			$toReturn["message"] = trans('lang.send-failure');
        		}else{
        			$toReturn["status"] = true;
        			$toReturn["message"] = trans('lang.send-success');
        		}
          }else{
            $toReturn["status"] = false;
            $toReturn["message"] = trans('lang.send-failure-recaptcha');
          }

		return json_encode($toReturn);
	}
	public function storageLink()
    {
        $directory = public_path('storage');
        File::deleteDirectory(public_path($directory));
        $storageLinkCode = Artisan::call('storage:link');
    }

}
