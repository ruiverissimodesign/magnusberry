<?php

namespace App\Http\Controllers;

use App\Product;
use App\ProductFile;
use App\ProductLang;
use App\ProductCategory;
use App\ProductCategoryFile;
use App\ProductCategoryLang;
use App\Languages;
use App\Section;
use App\Rank;
use App\AttributeProduct;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class ProductCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDir = '';

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDir = 'backoffice.product.';
    }

    public function productcatadd(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddProduct')->pluck('PERMISSIONS')[0] == "1"){
    		$langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->orderBy('STATUS', 'desc')->get();
    		$productCat = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
    			->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*')
                ->get();
    		$tabsAdjust = count($langs);
    		$tabsAdjust = 100 / $tabsAdjust;

            return view($this->prefixViewDir . 'productCategoryAdd')->with(
                [
                    'langs'=> $langs,
                    'tabsajust' => $tabsAdjust,
                    'product' => $productCat
                ]);
      }else{
        return redirect()->route('home');
      }
    }

    public function insert(Request $req)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')->select('LANGUAGE_ID', 'NAME', 'SLUG', 'STATUS')->get();
        $this->validation($req, $langs);
		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

		if($req->input("status") == TRUE){
			$status = 1;
		}

		$productCat = DB::table('product_category')->insertGetId([
            'C_PARENT_ID' => $req->input("parent"),
            'STATUS' => $status,
            'C_DISCOUNT' => (!empty($req->input("discount"))) ? $req->input("discount") : "0" ,
            'C_DISCOUNT_TYPE' => (!empty($req->input("discountType"))) ? $req->input("discountType") : "fix" ,
            'C_DISCOUNT_INIT' => $req->input("discountInit"),
            'C_DISCOUNT_END' => $req->input("discountEnd"),
            'C_DISCOUNT_PARENT' => (!empty($req->input("discountParent") && $req->input("discountParent") == "on")) ? "1" : "0" ,
            'DESTAQUE' => $req->input("destaque") === 'on' ? 1 : 0,
            'ORDER' => (!empty($req->input("order"))) ? $req->input("order") : "0" ,
        ]);

        if ($req->input("image_code")){
            $index=1;
            foreach ($req->input("image_code") as $image_id => $image_code) {
                $product_file = new ProductCategoryFile();
                $product_file->C_PRODUCT_ID = $productCat;
                $product_file->FILE_ID = $image_id;
                $product_file->CODE = $image_code === null ? '' : $image_code;
                $product_file->ORDER = $index;
                $product_file->save();
                $index++;
            }
        }

        foreach ($langs as $l => $lang) {
			DB::table('product_category_lang')->insert([
                'C_PRODUCT_ID' => $productCat,
                'LANGUAGE_ID' => $lang->LANGUAGE_ID,
                'NAME' => $req->input("name_{$lang->SLUG}"),
                'DESCRIPTION' => $req->input("description_{$lang->SLUG}")
            ]);

		}

        return redirect()->route('productList');
      }else{
        return redirect()->route('home');
      }
    }

	public function productcatedit(Request $req, $id){
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
            $langs = DB::table('a_languages')
				->join('product_category_lang', 'product_category_lang.LANGUAGE_ID', '=', 'a_languages.LANGUAGE_ID')
				->where('product_category_lang.C_PRODUCT_ID', '=', $id)
				->select('a_languages.LANGUAGE_ID', 'a_languages.NAME AS LG_NAME','a_languages.SLUG','a_languages.STATUS','product_category_lang.*')
				->orderBy('STATUS', 'desc')
				->get();
    		$product = DB::table('product_category')->select('product_category.*')->where('C_PRODUCT_ID', $id)->get();
    		$product2 = DB::table('product_category')
                ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
    			->where('product_category_lang.LANGUAGE_ID', '=', '1')
                ->select('product_category.*', 'product_category_lang.*')
                ->get();
    		$tabsajust = count($langs);
    		try{
    		    $tabsajust = 100 / $tabsajust;
            }catch (\Exception $e){
    		    abort(404);
            }

            $getParent = DB::table('product_category')->where('C_PRODUCT_ID','=',$id)->get();
            $idCrumb = $id;
            $crumb = TRUE;
            $crumbArray = [];
            while ($crumb == TRUE) {
                if ($idCrumb != -1) {
                    $getParent2 = DB::table('product_category')->where('C_PRODUCT_ID','=',$idCrumb)->select('C_PARENT_ID')->get();
                    $idCrumb = $getParent2[0]->C_PARENT_ID;
                    $productbreadcrumb = DB::table('product_category')
                    ->join('product_category_lang', 'product_category.C_PRODUCT_ID', '=', 'product_category_lang.C_PRODUCT_ID')
                    ->where('product_category_lang.LANGUAGE_ID', '=', '1')
                    ->where('product_category.C_PARENT_ID', '=', $idCrumb)
                    ->select('product_category.*', 'product_category_lang.*')
                    ->orderBy('ORDER')
                    ->get();

                    array_push($crumbArray, $productbreadcrumb);

                }else{
                    $crumb == FALSE;
                    break;
                }
            }

            $crumbArray = array_reverse($crumbArray);
            $product_file = ProductCategoryFile::where('C_PRODUCT_ID', $id)->orderby('ORDER','ASC')->get();
    		return view($this->prefixViewDir . 'productCategoryEdit')->with(
    		    [
    		        'langs'=> $langs,
                    'tabsajust'=> $tabsajust,
                    'product2'=> $product2,
                    'idback'=> $id,
                    'product'=> $product,
                    'product_file'=> $product_file,
                    'breadcrumb'=> $crumbArray,
                    'pgId'=> $id,
                ]);
        }else{
          return redirect()->route('home');
        }
	}

    public function update(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
        $langs = DB::table('a_languages')
            ->select('LANGUAGE_ID', 'NAME', 'SLUG','STATUS')
            ->get();
        $this->validation($req, $langs);

		$status = 0;
        $page_id = $req->input('page') !== -1 ? $req->input('page') : null ;

		if($req->input("status") == TRUE){
			$status = 1;
		}
		DB::table('product_category')
            ->where('C_PRODUCT_ID', $id)
            ->update([
                'C_PARENT_ID' => $req->input("parent"),
                'STATUS' => $status,
                'C_DISCOUNT' => (!empty($req->input("discount"))) ? $req->input("discount") : "0" ,
                'C_DISCOUNT_TYPE' => (!empty($req->input("discountType"))) ? $req->input("discountType") : "fix" ,
                'C_DISCOUNT_INIT' => $req->input("discountInit"),
                'C_DISCOUNT_END' => $req->input("discountEnd"),
                'C_DISCOUNT_PARENT' => (!empty($req->input("discountParent") && $req->input("discountParent") == "on")) ? "1" : "0" ,
                'DESTAQUE' => $req->input("destaque") === 'on' ? 1 : 0,
                'ORDER'=> $req->input("order")
            ]);

        foreach (ProductCategoryFile::where('C_PRODUCT_ID', $id)->get() as $value) {
            $value->delete();
        }
        if ($req->input("image_code")){
            $index=1;
            foreach ($req->input("image_code") as $image_id => $image_code) {
                $product_file = new ProductCategoryFile();
                $product_file->C_PRODUCT_ID = $id;
                $product_file->FILE_ID = $image_id;
                $product_file->CODE = $image_code === null ? '' : $image_code;
                $product_file->ORDER = $index;
                $product_file->save();
                $index++;
            }
        }

		foreach ($langs as $l => $lang) {
			DB::table('product_category_lang')
                ->where('C_PRODUCT_ID', $id)
                ->where('LANGUAGE_ID', $lang->LANGUAGE_ID)
                ->update([
                    'C_PRODUCT_ID' => $id,
                    'LANGUAGE_ID' => $lang->LANGUAGE_ID,
                    'NAME' => $req->input("name_{$lang->SLUG}"),
                    'DESCRIPTION' => $req->input("description_{$lang->SLUG}")
                ]);
		}
        return redirect()->route('productList');
      }else{
        return redirect()->route('home');
      }
    }
	public function remove(Request $req, $id) {
        if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListProduct')->pluck('PERMISSIONS')[0] == "1"){
    		DB::table('product_category')->where('C_PRODUCT_ID', '=', $id)->delete();
    		DB::table('product_category_lang')->where('C_PRODUCT_ID', '=', $id)->delete();
    		DB::table('product_category_file')->where('C_PRODUCT_ID', '=', $id)->delete();
    		return redirect()->route('productList');
        }else{
        return redirect()->route('home');
        }
	}

    public function validation(Request $request, Collection $languages){


        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),
            ]
        );
    }
}
