<?php

namespace App\Http\Controllers\API;

use App\Article;
use App\Banner;
use App\Category;
use App\Company;
use App\File;
use App\Http\Resources\BannerResources\BannerResource;
use App\Http\Resources\CategoryResources\CategoryResource;
use App\Http\Resources\CompanyResources\CompanyResource;
use App\Http\Resources\LanguagesResources\LanguageResource;
use App\Http\Resources\MenuResources\MenuResource;
use App\Http\Resources\PageResources\PageResource;
use App\Http\Resources\SectionResources\SectionResource;
use App\Languages;
use App\Menu;
use App\Page;
use App\Section;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

use Illuminate\Http\UploadedFile;
use App\Http\Controllers\Controller;
use App\Http\Controllers\FileController;
use App\Http\Resources\FileResources\FileResource;
use App\Http\Resources\ArticleResources\ArticleResource;

class api extends Controller
{
    /**
     * Returns all the information about the company as a json object
     */

    /**
     * Fetch data for company
     * @return CompanyResource|JsonResponse
     */
    public function getCompanyInfo($token)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $company = Company::first();

        if(!$company){
            return response()->json([
                'error'=> 'Data for company not found.',
                'code' => 404
            ], 404);
        }
        return new CompanyResource($company);
      }else{
        return "No permission";
      }
    }

    /**
     * Fetch data for files by id
     * @param $id
     * @param $language
     * @return FileResource|JsonResponse
     */
    public function getFileById($token, $id, $language){
      $token_api = config('app.token_api');
      if($token == $token_api){
        $file = File::find($id);

        if(!$file){
            return response()->json([
                'error'=> "File with that given id Doesn't Exist",
                'code' => 404
            ], 404);
        }

        return FileResource::make($file)->withLanguage($language);
      }else{
        return "No permission";
      }
    }

    /**
     * Fetch data for menu and submenus  by id
     * @param $id
     * @param $language
     * @return MenuResource|JsonResponse
     */
    public function getMenuById(Request $request, $token, $id, $language){


        $token_api = config('app.token_api');
        if($token == $token_api){
          $menu = Menu::find($id);

          if(!$menu){
            return response()->json([
              'error' => 'There is no menu with that given id.',
              'code' => 404
            ], 404);
          }

          if($menu->STATUS == 0){
            return response()->json([
              'error' => 'The menu with that given id has a status of 0',
              'code' => 404
            ], 404);
          }
          return MenuResource::make($menu)->withLanguage($language);
        }else{
          return "No permission";
        }
    }


    /**
     * Fetch data for article  by id
     * @param $id
     * @param $lang
     * @return ArticleResource|JsonResponse
     */
    public function getArticleById($token, $id, $lang)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $article = Article::find($id);
        if(!$article){
            return response()->json([
                'error' => 'There is no article with that given id.',
                'code' => 404
            ], 404);
        }
        if($article->STATUS == 0){
            return response()->json([
                'error' => 'Article with status of 0',
                'code' => 404
            ], 404);
        }
        return ArticleResource::make($article)->withLanguage($lang);
      }else{
        return "No permission";
      }
    }

    /**
     * Fetch data for category  by id and all the associated articles
     * @param int $id
     * @param string $lang
     * @return CategoryResource|JsonResponse
     */
    public function getCategoryById($token,int $id, string $lang)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $category = Category::find($id);
        if(!$category){
            return response()->json([
                'error' => 'There is no category with that given id.',
                'code' => 404
            ], 404);
        }


        if($category->STATUS == 0){
            return response()->json([
                'error' => 'The Category has a status of 0.',
                'code' => 400
            ], 400);
        }
        return CategoryResource::make($category)->withLanguage($lang);
      }else{
        return "No permission";
      }
    }

    /**
     * Fetch data for slideshow  by id and all the associated slideshow items
     * @param int $id
     * @param string $lang
     * @return BannerResource|JsonResponse
     */
    public function getSlideshowById($token, int $id, string $lang)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $slideshow = Banner::find($id);

        if(!$slideshow){
            return response()->json([
                'error' => 'There is no slideshow with that given id.',
                'code' => 404
            ], 404);
        }
        /*if($slideshow->STATUS == 0){
            return response()->json([
                'error' => 'The slideshow with that given id has a status of 0',
                'code' => 404
            ], 404);
        }*/ // Slide show has no status

        return BannerResource::make($slideshow)->withLanguage($lang);
      }else{
        return "No permission";
      }
    }

    /**
     * Fetch data for section  by id and all the associated data depending on the type
     * @param int $id
     * @param string $lang
     * @return SectionResource|JsonResponse
     */
    public function getSectionById($token, int $id, string $lang)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $section = Section::find($id);

        if(!$section){
            return response()->json([
                'error' => 'There is no section with that given id.',
                'code' => 404
            ], 404);
        }

        if($section->STATUS == 0){
            return response()->json([
                'error' => 'The section with that given id has a status of 0',
                'code' => 404
            ], 404);
        }

        return SectionResource::make($section)->withLanguage($lang);
      }else{
        return "No permission";
      }
    }

    public function getPageById($token, $id, $lang)
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        $page = Page::find($id);
        if(!$page){
            return response()->json([
                'error' => 'There is no page with that given id.',
                'code' => 404
            ], 404);
        }
        if($page->STATUS == 0){
            return response()->json([
                'error' => 'The page with that given id has a status of 0',
                'code' => 404
            ], 404);
        }
        return PageResource::make($page)->withLanguage($lang);
      }else{
        return "No permission";
      }
    }

    /**
     * Return the data from languages depending on status argument
     *
     * -> (1 or 'active') return all the languages with active status
     *
     * -> (0 or 'inactive') return all the languages with inactive status
     *
     * @param string $status 1|0|active|inactive|""
     * @return LanguageResource
     */
    public function getActiveLanguages($status = 'all'): LanguageResource
    {
      $token_api = config('app.token_api');
      if($token == $token_api){
        if($status === 'active' || $status === '1'){
            $languages = Languages::where('STATUS', 1)->get();
        }elseif($status === 'inactive' || $status === '0'){
            $languages = Languages::where('STATUS', 0)->get();
        }else{
            $languages = Languages::all();
        }
        return LanguageResource::make($languages);
      }else{
        return "No permission";
      }
    }

    /**
     * @param Request $request
     * @return array|UploadedFile|UploadedFile[]|null
     */
    public function uploadFile(Request $request){
      $token_api = config('app.token_api');
      if($token == $token_api){
        $fileDB = new File();
        $file = $request->file('files');

        $extension = $file->getClientOriginalExtension();
        $filename = 'frontend-uploads-' . time() . '.' . $extension;
        $fileDB->IMAGENAME = $filename;
        $fileDB->TYPE = $extension;
        $fileDB->FILE = $filename;

        $fileDB->ISIMAGE = FileController::isFileAImage($extension) ? 1 : 0;


        $file->storeAs('frontend_uploads', $filename);

        // If i save that image, it will give error on multimedia page (possible fix: copy the image to the original paste and save this model to the db
        // $fileDB->save();
        return FileResource::make($fileDB)->withLanguage(Languages::first()->SLUG);
      }else{
        return "No permission";
      }
    }
}
