<?php

namespace App\Http\Controllers;

use App\Article;
use App\ArticleFile;
use App\ArticleLang;
use App\Languages;
use App\Section;
use App\Rank;
use Auth;
use App\SectionArticle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;

class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $prefixViewDir = '';

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDir = 'backoffice.article.';
    }

    public function index()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListArticle')->pluck('PERMISSIONS')[0] == "1"){
        $articles = Article::orderBy('ORDER')->get();

        return view($this->prefixViewDir . 'index', compact('articles'));
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddArticle')->pluck('PERMISSIONS')[0] == "1"){
        $languages = \App\Languages::orderBy('STATUS', 'desc')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;
        $teamplates = DB::table('teamplate')->where('TYPE','article')->get();
        return view($this->prefixViewDir . 'create')->with([
            'languages' => $languages,
            'tabsAdjust' => $tabsAdjust,
            'teamplates' => $teamplates
        ]);
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddArticle')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $article = new Article();

        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
          }
        }

        $defaultRules = [
        ];

        $validate = $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),

            ]
        );
        // BASIS FOR ARTICLE
        $article->TEAMPLATE = $request->input('select_tp');
        $article->AUTHOR = $request->input('author') ?: ''; // if it has a value assign it else put a empty string
        $article->CATEGORY = $request->input('category'); // needed
        $article->ORDER = $request->input('order') ?: 0; // if it has a value assign it else put a 0

        $article->DESTAQUE = $request->input('destaque') === 'on' ? 1 : 0;
        $article->STATUS = $request->input('status') === 'on' ? 1 : 0;

        $article->save();

        // TRADÇOES
        foreach ($languages as $lang) {
            $article_lang = new ArticleLang();

            $article_lang->LANGUAGE_ID = $lang->LANGUAGE_ID;
            $article_lang->ARTICLE_ID = $article->ARTICLE_ID;

            $article_lang->NAME_SEO = $request->input("name_{$lang->SLUG}");
            $article_lang->TEXT_SEO = $request->input("text_{$lang->SLUG}");
            $article_lang->save();

        }

        // FILES
        if ($request->input("image_code")) {
            $index=1;
            foreach ($request->input("image_code") as $image_id => $image_code) {
                $article_file = new ArticleFile();
                $article_file->ARTICLE_ID = $article->ARTICLE_ID;
                $article_file->FILE_ID = $image_id;
                $article_file->CODE = $image_code === null ? '' : $image_code;
                $article_file->ORDER = $index;
                $article_file->save();
                $index++;
            }
        }


        $request->session()->flash('status', \Lang::get('system.article-created'));

        return back();
      }else{
        return redirect()->route('home');
      }


    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function replicate($id)
    {

      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListArticle')->pluck('PERMISSIONS')[0] == "1"){
        $article_replicate = Article::findOrFail($id);
        $article = $article_replicate->replicate();
        $article->save();

        if (ArticleLang::where('ARTICLE_ID', $article_replicate->ARTICLE_ID)) {
            foreach (ArticleLang::where('ARTICLE_ID', $article_replicate->ARTICLE_ID)->get() as $article_lang_replicate) {
                $article_lang = $article_lang_replicate->replicate();
                $article_lang->ARTICLE_ID = $article->ARTICLE_ID;
                $article_lang->save();
            }
        }

        if (ArticleFile::where('ARTICLE_ID', $article_replicate->ARTICLE_ID)) {
            foreach (ArticleFile::where('ARTICLE_ID', $article_replicate->ARTICLE_ID)->get() as $article_file_replicate) {
                $article_file = $article_file_replicate->replicate();
                $article_file->ARTICLE_ID = $article->ARTICLE_ID;
                $article_file->save();
            }
        }


        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $article_file = ArticleFile::where('ARTICLE_ID', $article->ARTICLE_ID)->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;

        $teamplates = DB::table('teamplate')->where('TYPE','article')->get();

        return view($this->prefixViewDir . 'edit')->with([
            'article' => $article,
            'tabsAdjust' => $tabsAdjust,
            'languages' => $languages,
            'teamplates' => $teamplates,
            'article_file' => $article_file,
            'pathBack' => route('article.index')
        ]);
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @param $pathBack
     * @return \Illuminate\Http\Response
     */
    public function edit($id, $pathBack = null)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListArticle')->pluck('PERMISSIONS')[0] == "1"){
        if(!$pathBack){
            $pathBack = route('article.index');
        }

        $article = Article::findOrFail($id);

        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $article_file = ArticleFile::where('ARTICLE_ID', $article->ARTICLE_ID)->orderBy('ORDER','ASC')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;

        $teamplates = DB::table('teamplate')->where('TYPE','article')->get();

        return view($this->prefixViewDir . 'edit')->with([
            'article' => $article,
            'tabsAdjust' => $tabsAdjust,
            'languages' => $languages,
            'article_file' => $article_file,
            'teamplates' => $teamplates,
            'pathBack' => $pathBack
        ]);
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id){
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListArticle')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if($lang->STATUS == "1"){
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
          }
        }

        $defaultRules = [
        ];

        $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),

            ]
        );
        $article = Article::findOrFail($id);

        // BASIS FOR ARTICLE
        $article->TEAMPLATE = $request->input('select_tp');
        $article->AUTHOR = $request->input('author') ? $request->input('author') : ''; // if it has a value assign it else put a empty string
        $article->CATEGORY = $request->input('category'); // needed
        $article->ORDER = $request->input('order') ? $request->input('order') : 0; // if it has a value assign it else put a 0
        $article->DESTAQUE = $request->input('destaque') === 'on' ? 1 : 0;

        $article->save();

        // TRADÇOES

        foreach ($languages as $lang) {
            $article_lang = ArticleLang::firstOrCreate(['ARTICLE_ID' => $article->ARTICLE_ID, 'LANGUAGE_ID' => $lang->LANGUAGE_ID]);

            $article_lang->LANGUAGE_ID = $lang->LANGUAGE_ID;
            $article_lang->ARTICLE_ID = $article->ARTICLE_ID;


            $article_lang->NAME_SEO = $request->input("name_{$lang->SLUG}");
            $article_lang->TEXT_SEO = $request->input("text_{$lang->SLUG}");
            $article_lang->save();
        }

        foreach (ArticleFile::where('ARTICLE_ID', $article->ARTICLE_ID)->get() as $value) {
            $value->delete();
        }

        if ($request->input("image_code")) {
            $index = 1;
            foreach ($request->input("image_code") as $image_id => $image_code) {
                $article_file = new ArticleFile();
                $article_file->ARTICLE_ID = $article->ARTICLE_ID;
                $article_file->FILE_ID = $image_id;
                $article_file->CODE = $image_code === null ? '' : $image_code;
                $article_file->ORDER = $index;
                $article_file->save();
                $index++;
            }
        }

        $request->session()->flash('status', \Lang::get('system.article-update'));

        return redirect()->route('article.index');
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $req, $id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListArticle')->pluck('PERMISSIONS')[0] == "1"){
        //Find the file
        foreach(ArticleFile::where('ARTICLE_ID', $id)->get() as $file){
            $file->delete();
        }
        foreach(ArticleLang::where('ARTICLE_ID', $id)->get() as $trad){
            $trad->delete();
        }
        Section::where([
            'TYPE' => 'article',
            'ITEMID' => $id
        ])->update([
            'ITEMID' => null
        ]);

        foreach(SectionArticle::where('ARTICLE_ID', $id)->get() as $article_section){
            $article_section->delete();
        }

        Article::findOrFail($id)->delete();

        // Remove that single article from sections with that article assossiated




        $req->session()->flash('alert-success', Lang::get('system.article-removeArticle-success'));
        return back();
      }else{
        return redirect()->route('home');
      }
    }


}
