<?php

namespace App\Http\Controllers;

use App\Languages;
use App\Menu;
use App\Page;
use App\PageLang;
use App\Section;
use App\SectionPage;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\View\View;
use App\Rank;
use Auth;

class PageController extends Controller
{
    /**
     * @var string
     */
    private $prefixViewDirFile;

    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFile = 'backoffice.page.';
    }
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        $pages = Page::all();
        return view($this->prefixViewDirFile . 'index', compact('pages'));
      }else{
        return redirect()->route('home');
      }
    }

    public function show($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        $page = Page::findOrFail($id);
        $page_lang = PageLang::where('PAGE_ID', $page->PAGE_ID)->where('LANGUAGE_ID', '1')->first();
        $sections = [];
        $sections = DB::table('section')
                    ->join('section_page','section.SECTION_ID','=','section_page.SECTION_ID')
                    ->select('section_page.*', 'section.*')
                    ->orderBy('ORDER')
                    ->get();
        $menus_associated = Menu::where('PAGE_ID', $page->PAGE_ID)->get();
        // dd($sections);
        return view($this->prefixViewDirFile . 'show', compact('page', 'page_lang', 'menus_associated', 'sections'));
      }else{
        return redirect()->route('home');
      }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return View
     */
    public function create(): View
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddPage')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;

        // Get Menu Items

        // Get Sections
        $sections = Section::where('STATUS', 1)->get();

        return view($this->prefixViewDirFile . 'create')
            ->with([
                'tabsAdjust'   => $tabsAdjust,
                'languages'    => $languages,
                'sections'    => $sections,

            ]);

      }else{
        return view('home');
      }
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|View
     */
    public function replicate($id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        $original_page = Page::findOrFail($id);
        $replicate_page = $original_page->replicate();
        $replicate_page->save();
        foreach (PageLang::where('PAGE_ID', $original_page->PAGE_ID)->get() as $lang) {
            $new_lang = $lang->replicate();
            $new_lang->PAGE_ID = $replicate_page->PAGE_ID;
            $new_lang->save();
        }
        foreach (SectionPage::where('PAGE_ID', $original_page->PAGE_ID)->get() as $section) {
            $newSection = $section->replicate();
            $newSection->PAGE_ID = $replicate_page->PAGE_ID;
            $newSection->save();
        }

        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;
        $sections = Section::where('STATUS', 1)->get();

        $page = Page::findOrFail($replicate_page->PAGE_ID);
        $section_page = SectionPage::where('PAGE_ID', $page->PAGE_ID)->get();

        return view($this->prefixViewDirFile . 'edit')->with([
            'page' => $page,
            'sections' => $sections,
            'tabsAdjust' => $tabsAdjust,
            'languages'=> $languages,
            'section_page' => $section_page,
            'pathBack' => route('page.index')
        ]);
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return RedirectResponse
     */
    public function store(Request $request): RedirectResponse
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','AddPage')->pluck('PERMISSIONS')[0] == "1"){
     /*   dd($request->all());*/
        $page = new Page();
        $languages = Languages::orderBy('STATUS', 'desc')->get();

        $this->validation($request, $languages); //resolução para o erro da section
        //Important to validate before generating the id
        $page->STATUS = $request->input('status') == 'on' ? 1 : 0;
        $page->save(); // To generate a id

        // TRADÇOES
        foreach ($languages as $lang) {
            $page_lang = new PageLang();
            $this->defaultPageLanguageCamps($request, $page, $page_lang, $lang);
        }

        // Secçoes
        // dd($request->input('section'));
        if(!empty($request->input('section'))){
			$index=1;
          foreach($request->input('section') as $section){
            $section_page = new SectionPage();
            $this->defaultSectionPageCamps($section_page, $page, $section,$index);
			$index++;
          }
        }
        $request->session()->flash('status', \Lang::get('system.page-created'));
        return redirect()->route('page.index');
      }else{
        return redirect()->route('home');
      }
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return View
     */
    public function disassociateSection(Request $request, $page_id, $section_id, $order)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        $getOne = SectionPage::where(['SECTION_ID' => $section_id, 'PAGE_ID' => $page_id, 'order' => $order])->first();
        SectionPage::where('ID', $getOne->ID)->delete();
        $request->session()->flash('status', 'Section was dissassociate successfully');
        return back();
      }else{
        return redirect()->route('home');
      }
    }
    public function disassociateMenu(Request $request, $page_id, $menu_id)
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        Menu::where(['PAGE_ID'=> $page_id, 'MENU_ID'=> $menu_id])->update([
            'PAGE_ID' => -1
        ]);
        $request->session()->flash('status', 'Menu was dissassociate successfully');
        return back();
      }else{
        return redirect()->route('home');
      }
    }
    public function edit($id, $pathBack=null): View
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        if(!$pathBack){
            $pathBack = route('page.index');
        }
        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $tabsAdjust = count($languages);
        $tabsAdjust = 100 / $tabsAdjust;
        $sections = Section::where('STATUS', 1)->get();

        $page = Page::findOrFail($id);
        $section_page = SectionPage::where('PAGE_ID', $page->PAGE_ID)->orderBy('ORDER','ASC')->get();

        return view($this->prefixViewDirFile . 'edit')->with([
            'page' => $page,
            'sections' => $sections,
            'tabsAdjust' => $tabsAdjust,
            'languages'=> $languages,
            'section_page' => $section_page,
            'pathBack' => $pathBack
        ]);
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return RedirectResponse
     */
    public function update(Request $request, $id): RedirectResponse
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        $languages = Languages::orderBy('STATUS', 'desc')->get();
        $this->validation($request, $languages);
        //Important to validate before generating the id
        $page = Page::findOrFail($id);
        $page->STATUS = $request->input('status') == 'on' ? 1 : 0;
        $page->save(); // To generate a id
        // TRADÇOES
        foreach ($languages as $lang) {
            $page_lang = PageLang::where(['LANGUAGE_ID' => $lang->LANGUAGE_ID, 'PAGE_ID' => $page->PAGE_ID])->first();
            $this->defaultPageLanguageCamps($request, $page, $page_lang, $lang);
        }

        foreach(SectionPage::where('PAGE_ID', $page->PAGE_ID)->get() as $itemToRemove){
            $itemToRemove->delete();
        }
        if($request->input('section')){
			$index=1;
            foreach($request->input('section') as $section){
                $section_page = new SectionPage();
                $this->defaultSectionPageCamps($section_page, $page, $section,$index);
				$index++;
            }
        }



        $request->session()->flash('status', Lang::get('system.page-updated'));
        return redirect()->route('page.index');
      }else{
        return redirect()->route('home');
      }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Request $request
     * @param int $id
     * @return RedirectResponse
     */
    public function destroy(Request $request, $id): RedirectResponse
    {
      if(Auth::user()->rank != "Member" OR Rank::where('AREA','=','ListPage')->pluck('PERMISSIONS')[0] == "1"){
        foreach(Menu::where('PAGE_ID', $id)->get() as $menu){
            $menu->PAGE_ID = -1;
            $menu->save();
        }
        foreach(PageLang::where('PAGE_ID', $id)->get() as $menu){
            $menu->delete();
        }

        Page::findOrFail($id)->delete();

        $request->session()->flash('alert-success', Lang::get('system.page-remove-success'));

        return redirect()->route('page.index');
      }else{
        return redirect()->route('home');
      }
    }

    /**
     * @param Request $request
     * @param Page $page
     * @param PageLang $page_lang
     * @param Languages $lang
     */
    public function defaultPageLanguageCamps(Request $request, Page $page, PageLang $page_lang, Languages $lang): void
    {

        $page_lang->LANGUAGE_ID = $lang->LANGUAGE_ID;
        $page_lang->PAGE_ID = $page->PAGE_ID;

        $page_lang->NAME_SEO = $request->input("name_{$lang->SLUG}");
        $page_lang->save();

    }

    /**
     * @param Request $request
     * @param Collection $languages
     * @return mixed
     */
    public function validation(Request $request, Collection $languages)
    {


        // This is needed to validate multiple languages camps
        $array_of_name_langs_to_validate = [];
        foreach ($languages as $lang) {
          if ($lang->STATUS == "1") {
            $array_of_name_langs_to_validate += ["name_{$lang->SLUG}" => 'required|min:3|max:50'];
          }
        }

        $defaultRules = [
        ];
        return $request->validate(
            array_merge($defaultRules, $array_of_name_langs_to_validate),
            [
                'required' => \Lang::get('system.edit-error-name-required'),
                'min' => \Lang::get('system.edit-error-name-min'),
                'max' => \Lang::get('system.edit-error-name-max'),

            ]
        );
    }

    /**
     * @param SectionPage $section_page
     * @param Page $page
     * @param array $section
     */
    private function defaultSectionPageCamps(SectionPage $section_page, Page $page, Array $section, $order): void
    {
        if(isset($section['SECTION_ID'])){
            $section_page->SECTION_ID = $section['SECTION_ID'];
            $section_page->PAGE_ID = $page->PAGE_ID;
            // $section_page->ORDER = $section['ORDER'];
            $section_page->ORDER = $order;

            $section_page->save();
        }

    }
}
