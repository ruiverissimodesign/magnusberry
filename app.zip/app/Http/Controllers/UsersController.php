<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Rank;
use App\Modulos;
use Auth;
use Image;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->prefixViewDirFiles = 'backoffice.user.';
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $req, $id)
    {
      $logged = Auth::user();
      $user = User::findOrFail($id);
      if(Auth::user()->rank != "Member" OR Auth::user()->id == $id){
        if($user->rank == "SuperAdmin"){
          if(Auth::user()->rank == "SuperAdmin"){
            return view($this->prefixViewDirFiles . 'useredit')->withUser($user)->with('logged',$logged);
          }else{
            return redirect()->route('home');
          }
        }else{
          return view($this->prefixViewDirFiles . 'useredit')->withUser($user)->with('logged',$logged);
        }
      }else{
        return redirect()->route('home');
      }
    }

	public function update(Request $req, $id) {
    if(Auth::user()->rank != "Member" OR Auth::user()->id === intval($id)){
		$user = User::findOrFail($id);
    if(Auth::user()->rank == "Member"){
      if($req->input('password')){
        $req->validate([
          'name'=>'required',
          'email'=>'required',
          'password' => 'min:6',
          'Repeat_Password' => 'required_with:password|same:password|min:6'
        ]);
        $user->password = bcrypt($req->input('password'));
      }else{
        $req->validate([
          'name'=>'required',
          'email'=>'required'
        ]);
      }
    }else{
      if($req->input('password')){
        $req->validate([
          'name'=>'required',
          'email'=>'required',
          'rank'=>'required',
          'password' => 'min:6',
          'Repeat_Password' => 'required_with:password|same:password|min:6'
        ]);
        $user->password = bcrypt($req->input('password'));
      }else{
        $req->validate([
          'name'=>'required',
          'email'=>'required',
          'rank'=>'required'
        ]);
      }
    }

		if($req->file('avatar')){
			$avatar = $req->file('avatar');
			$filename = $user->id.'_avatar'.time().'.'. $avatar->getClientOriginalExtension();
			Image::make($avatar)->resize(300,300)->save( public_path('/uploads/avatars/' . $filename) );
			$user->avatar = $filename;
		}

		$user->name = $req->input("name");
		$user->email = $req->input("email");
    if(Auth::user()->rank != "Member"){
      if(Auth::user()->rank == "Admin"){
        if($req->input("rank") == "Admin" OR $req->input("rank") == "Member"){
          $user->rank = $req->input("rank");
        }
      }else{
        $user->rank = $req->input("rank");
      }
    }

    		$user->save();
        $req->session()->flash('alert-success', 'The User has been created');
        return redirect()->route('userList');
      }else{
        return redirect()->route('home');
      }
	}
	public function list(Request $req)
    {
      if(Auth::user()->rank != "Member"){
		$users = User::all();
        return view($this->prefixViewDirFiles . 'userlist', compact('users'));
      }else{
        return redirect()->route('home');
      }
    }
	public function remove(Request $req, $id) {
    if(Auth::user()->rank != "Member" && $id != 1){
		User::destroy ($id);
		return redirect()->route('userList');
  }else{
    return redirect()->route('home');
  }
	}
	public function memberPerm(Request $req) {
    if(Auth::user()->rank != "Member"){
        $rank = Rank::get();
        $modulos = Modulos::get();
		return view('backoffice.rank.index')->with('rank', $rank)->with('modulos', $modulos);
  }else{
    return redirect()->route('home');
  }
	}
	public function memberUpdate(Request $req) {
    if(Auth::user()->rank != "Member"){
    $ranks = Rank::get();
    foreach ($ranks as $r => $rs) {
      if("on" == $req->input("rank_{$rs->ID}")){
        $estado = "1";
      }  else {
        $estado = "0";
      }
      $aa = DB::table('rank_permissions')->where('ID', $rs->ID)->update(['PERMISSIONS' => $estado]);
    }
		return redirect()->route('memberPerm');
  }else{
    return redirect()->route('home');
  }
	}

}
