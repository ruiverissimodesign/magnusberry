<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class OnlySuperAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */

    protected $superAdminList;

    public function __construct()
    {
        $this->superAdminList = explode(',', env('SUPER_ADMINS'));
    }

    public function handle($request, Closure $next)
    {
        if(!in_array(Auth::user()->email, $this->superAdminList, true))
        {
            abort(403);
        }

        return $next($request);
    }
}
