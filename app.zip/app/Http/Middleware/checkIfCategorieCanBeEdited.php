<?php

namespace App\Http\Middleware;

use Closure;

class checkIfCategorieCanBeEdited
{

    protected $protectedCategoriesId = [1, 2];
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $id = (int) $request->id;

        if(
            in_array($id, $this->protectedCategoriesId, true)
        ){
            abort(403);
        }
        else{
            return $next($request);
        }
    }
}
