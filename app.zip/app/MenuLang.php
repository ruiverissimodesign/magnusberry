<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuLang extends Model
{
    protected $table="d_menu_lang";
	protected $primaryKey = "MENU_LANG_ID";
	public $timestamps = false;
}
