<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    protected $table="d_menu";
	protected $primaryKey = "MENU_ID";
	public $timestamps = false;
}
