<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionProduct extends Model
{
    protected $table = 'section_product';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['SECTION_ID', 'PRODUCT_ID'];
}
