<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategoryLang extends Model
{
    protected $table = 'product_category_lang';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['C_PRODUCT_ID', 'LANGUAGE_ID', "NAME", "DESCRIPTION"];
}
