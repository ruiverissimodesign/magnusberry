<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class AttributeValue extends Model
{
    protected $table="attribute_value";
	protected $primaryKey = "ATTRIBUTE_VALUE_LANG_ID";
	public $timestamps = false;
}
