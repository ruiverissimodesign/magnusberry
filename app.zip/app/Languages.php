<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static where(string $string, string $string1)
 */
class Languages extends Model
{
    protected $table="a_languages";
	protected $primaryKey = "LANGUAGE_ID";
	public $timestamps = false;
}
