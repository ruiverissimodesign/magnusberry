<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductLang extends Model
{
    protected $table = 'product_lang';
    protected $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = ['PRODUCT_ID', 'LANGUAGE_ID', "NAME", "DESCRIPTION"];
}
