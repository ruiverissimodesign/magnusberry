<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticleLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('article_lang', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('ARTICLE_ID')->unsigned()->nullable();
            $table->bigInteger('LANGUAGE_ID')->unsigned()->nullable();
            $table->string('NAME_SEO')->nullable();
            $table->longText('TEXT_SEO')->nullable();


            $table->foreign('ARTICLE_ID')->references('ARTICLE_ID')->on('article')->onDelete('CASCADE');
            $table->foreign('LANGUAGE_ID')->references('LANGUAGE_ID')->on('a_languages')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('article_lang');
    }
}
