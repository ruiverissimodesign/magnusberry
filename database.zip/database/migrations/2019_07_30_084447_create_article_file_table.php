<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticleFileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('article_file', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('ARTICLE_ID')->unsigned()->nullable();
            $table->bigInteger('FILE_ID')->unsigned()->nullable();
            $table->string('CODE')->nullable();
            $table->integer('ORDER')->nullable();

            $table->foreign('ARTICLE_ID')->references('ARTICLE_ID')->on('article')->onDelete('CASCADE');
            $table->foreign('FILE_ID')->references('FILE_ID')->on('files')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('article_file');
    }
}
