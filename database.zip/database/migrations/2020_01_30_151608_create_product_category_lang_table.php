<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductCategoryLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_category_lang', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('C_PRODUCT_ID')->unsigned()->nullable();
            $table->bigInteger('LANGUAGE_ID')->unsigned()->nullable();
            $table->string('NAME')->nullable();
            $table->longText('DESCRIPTION')->nullable();


            $table->foreign('C_PRODUCT_ID')->references('C_PRODUCT_ID')->on('product_category')->onDelete('CASCADE');
            $table->foreign('LANGUAGE_ID')->references('LANGUAGE_ID')->on('a_languages')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_category_lang');
    }
}
