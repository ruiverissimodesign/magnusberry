<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSectionArticleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('section_article', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->biGInteger('ARTICLE_ID')->nullable()->unsigned();
            $table->biGInteger('SECTION_ID')->nullable()->unsigned();


            $table->foreign('ARTICLE_ID')->references('ARTICLE_ID')->on('article')->onDelete('cascade');
            $table->foreign('SECTION_ID')->references('SECTION_ID')->on('section')->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('section_article');
    }
}
