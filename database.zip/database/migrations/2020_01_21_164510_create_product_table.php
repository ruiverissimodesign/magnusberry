<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product', function (Blueprint $table) {
            $table->bigIncrements('PRODUCT_ID');
            $table->integer('PARENT_ID')->default(0);
            $table->integer('CODE')->nullable();
            $table->float('PRICE')->nullable();
            $table->float('DISCOUNT')->default(0);
            $table->enum('DISCOUNT_TYPE', ['fix', 'percentage'])->default("fix");
            $table->date('DISCOUNT_INIT')->nullable();
            $table->date('DISCOUNT_END')->nullable();
            $table->integer('DISCOUNT_PARENT')->default(1);
            $table->integer('STOCK')->default(0);
            $table->integer('STATUS')->default(0);
            $table->integer('ORDER')->default(0)->nullable();
            $table->integer('DESTAQUE')->default(0);
            $table->longText("CUSTOMCAMPS")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product');
    }
}
