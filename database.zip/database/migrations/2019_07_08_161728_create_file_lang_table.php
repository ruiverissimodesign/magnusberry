<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFileLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('file_lang', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('FILE_ID')->unsigned()->nullable();
            $table->bigInteger('LANGUAGE_ID')->unsigned()->nullable();
            $table->string('DESCRIPTION')->default('No description for the current language')->nullable();
            $table->timestamps();


            // When the file with the given id is deleted, this record will be deleted aswell
            $table->foreign('FILE_ID')->references('FILE_ID')->on('files')->onDelete('cascade');
            // When the language with the given id is deleted, this record will be deleted aswell
            $table->foreign('LANGUAGE_ID')->references('LANGUAGE_ID')->on('A_LANGUAGES')->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('file_lang');
    }
}
