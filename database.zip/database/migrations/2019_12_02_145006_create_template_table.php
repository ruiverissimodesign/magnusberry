<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTemplateTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teamplate', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->string('NAME');
            $table->string('FILE');
            $table->enum('TYPE', ['section', 'article', 'banner']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teamplate');
    }
}
