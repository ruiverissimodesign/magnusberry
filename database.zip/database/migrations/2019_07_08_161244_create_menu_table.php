<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenuTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_menu', function (Blueprint $table) {
            $table->bigIncrements('MENU_ID');
			      $table->integer('PARENT_ID')->default("-1");
            $table->integer('PAGE_ID')->default(null)->nullable();
            $table->string('STATUS');
            $table->integer('ORDER')->default("0");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_menu');
    }
}
