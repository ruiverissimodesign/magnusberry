<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductFileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_file', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('PRODUCT_ID')->unsigned()->nullable();
            $table->bigInteger('FILE_ID')->unsigned()->nullable();
            $table->string('CODE')->nullable();
            $table->integer('ORDER')->nullable();

            $table->foreign('PRODUCT_ID')->references('PRODUCT_ID')->on('product')->onDelete('CASCADE');
            $table->foreign('FILE_ID')->references('FILE_ID')->on('files')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_file');
    }
}
