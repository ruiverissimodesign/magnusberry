<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSectionPageTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('section_page', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('PAGE_ID')->unsigned();
            $table->bigInteger('SECTION_ID')->unsigned();
            $table->integer('ORDER')->default(0)->nullable();

            $table->foreign('PAGE_ID')->references('PAGE_ID')->on('page')->onDelete('CASCADE');
            $table->foreign('SECTION_ID')->references('SECTION_ID')->on('section')->onDelete('CASCADE');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('section_page');
    }
}
