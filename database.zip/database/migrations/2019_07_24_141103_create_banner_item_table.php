<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBannerItemTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('e_banner_item', function (Blueprint $table) {
            $table->bigIncrements('BANNER_ITEM_ID');
			$table->integer('BANNER_ID');
			$table->integer('IMG_ID');
			$table->integer('ORDER')->nullable();
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('banner_item');
    }
}
