<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductCategoryFileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_category_file', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('C_PRODUCT_ID')->unsigned()->nullable();
            $table->bigInteger('FILE_ID')->unsigned()->nullable();
            $table->string('CODE')->nullable();
            $table->integer('ORDER')->nullable();

            $table->foreign('C_PRODUCT_ID')->references('C_PRODUCT_ID')->on('product_category')->onDelete('CASCADE');
            $table->foreign('FILE_ID')->references('FILE_ID')->on('files')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_category_file');
    }
}
