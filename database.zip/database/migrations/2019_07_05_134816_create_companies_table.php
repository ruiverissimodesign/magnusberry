<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('a_company', function (Blueprint $table) {
            $table->bigIncrements('COMPANY_ID');
            $table->char('NAME', 255);
            $table->char('LOGO', 255)->nullable();
            $table->char('LOGO_ALTERNATIVE', 255)->nullable();
            $table->char('FAVICON', 255)->nullable();
            $table->char('LOGOPRINT', 255)->nullable();
            $table->char('NIF', 255)->nullable();
            $table->char('ADDRESS', 255)->nullable();
            $table->char('POSTCODE', 10)->nullable();
            $table->char('CITY', 255)->nullable();
            $table->char('COUNTRY', 255)->nullable();
            $table->char('PHONE', 255)->nullable();
            $table->char('MOBILE', 255)->nullable();
            $table->char('EMAIL', 255)->nullable();
            $table->char('MAP', 255)->nullable();
            $table->char('LATITUDE', 255)->nullable();
            $table->char('LONGITUDE', 255)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('A_COMPANY');
    }
}
