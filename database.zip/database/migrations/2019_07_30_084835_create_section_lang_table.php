<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSectionLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('section_lang', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->integer('SECTION_ID');
            $table->integer('LANGUAGE_ID');
            $table->string('NAME_SEO')->nullable();
            $table->longText('TEXT_SEO')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('section_lang');
    }
}
