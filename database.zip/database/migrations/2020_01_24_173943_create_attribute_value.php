<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAttributeValue extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attribute_value', function (Blueprint $table) {
            $table->bigIncrements('ATTRIBUTE_VALUE_LANG_ID');
            $table->integer('ATTRIBUTE_ID');
            $table->integer('LANGUAGE_ID');
            $table->integer('ATTRIBUTE_VALUE_ID')->nullable();
			$table->string('A_VALUE')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attribute_value');
    }
}
