<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenuLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_menu_lang', function (Blueprint $table) {
            $table->bigIncrements('MENU_LANG_ID');
            $table->integer('MENU_ID');
            $table->integer('LANGUAGE_ID');
            $table->string('M_NAME')->nullable();
            $table->string('URL')->nullable();
            $table->string('TITLE_SEO')->nullable();
            $table->string('DESCRIPTION_SEO')->nullable();
            $table->string('KEYWORDS_SEO')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_menu_lang');
    }
}
