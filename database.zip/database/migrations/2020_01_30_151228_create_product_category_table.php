<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductCategoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_category', function (Blueprint $table) {
            $table->bigIncrements('C_PRODUCT_ID');
            $table->integer('C_PARENT_ID')->default(0);
            $table->float('C_DISCOUNT')->default(0);
            $table->enum('C_DISCOUNT_TYPE', ['fix', 'percentage'])->default("fix");
            $table->date('C_DISCOUNT_INIT')->nullable();
            $table->date('C_DISCOUNT_END')->nullable();
            $table->integer('C_DISCOUNT_PARENT')->default(1);
            $table->integer('STATUS')->default(0);
            $table->integer('ORDER')->default(0)->nullable();
            $table->integer('DESTAQUE')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_category');
    }
}
