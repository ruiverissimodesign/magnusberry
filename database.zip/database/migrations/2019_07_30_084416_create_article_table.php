<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('article', function (Blueprint $table) {
            $table->bigIncrements('ARTICLE_ID');
            $table->bigInteger('CATEGORY')->unsigned();
            $table->string('TEAMPLATE')->default('default');
            $table->integer('STATUS')->default(1);
            $table->string('AUTHOR')->nullable();
            $table->string('DESTAQUE')->default(0);
            $table->integer('ORDER')->nullable();
            $table->longText("CUSTOMCAMPS")->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('article');
    }
}
