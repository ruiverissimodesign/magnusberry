<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductLangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_lang', function (Blueprint $table) {
            $table->bigIncrements('ID');
            $table->bigInteger('PRODUCT_ID')->unsigned()->nullable();
            $table->bigInteger('LANGUAGE_ID')->unsigned()->nullable();
            $table->string('NAME')->nullable();
            $table->longText('DESCRIPTION')->nullable();


            $table->foreign('PRODUCT_ID')->references('PRODUCT_ID')->on('product')->onDelete('CASCADE');
            $table->foreign('LANGUAGE_ID')->references('LANGUAGE_ID')->on('a_languages')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_lang');
    }
}
