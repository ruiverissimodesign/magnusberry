<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAttributeName extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attribute_name', function (Blueprint $table) {
			$table->bigIncrements('ATTRIBUTE_NAME_LANG_ID');
			$table->integer('ATTRIBUTE_ID');
			$table->integer('LANGUAGE_ID');
			$table->string('A_NAME')->nullable();
			$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attribute_name');
    }
}
