<?php

use Illuminate\Database\Seeder;

class categoryDefault extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
			[
                'PARENT_ID' => -1,
                'NAME' => "MASTER CATEGORY",
            ],
            [
                'PARENT_ID' => -1,
                'NAME' => "NO CATEGORY",
            ]
        ]);
    }
}
