<?php

use Illuminate\Database\Seeder;

class userDefault extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('users')->insert([
            'name' => "critec",
            'email' => "critec@critec.pt",
            'password' => bcrypt(')DfzhWj6HB[{r_W!'),
            'rank' => "SuperAdmin",
            'status' => "1"
        ]);
    }
}
