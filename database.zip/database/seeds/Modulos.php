<?php

use Illuminate\Database\Seeder;

class Modulos extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('modulos')->insert([
            ['MODULO'=>'Newsletter'],
            ['MODULO'=>'Products'],
            ['MODULO'=>'Attribute']
        ]);
    }
}
