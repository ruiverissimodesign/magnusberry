<?php

use Illuminate\Database\Seeder;

class rankMember extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('rank_permissions')->insert([
          [
              'AREA'=>'Home',
              'PERMISSIONS'=> '1',
          ],
          [
              'AREA'=>'AddMenu',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListMenu',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListLang',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddSlide',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListSlide',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddCat',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListCat',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddArticle',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListArticle',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddSection',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListSection',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddPage',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListPage',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'Company',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'Multimedia',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'Newsletter',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'ListProduct',
              'PERMISSIONS'=> '0',
          ],
          [
              'AREA'=>'AddProduct',
              'PERMISSIONS'=> '0',
          ]
      ]);
    }
}
