<?php

use Illuminate\Database\Seeder;

class addLanguagesDefault extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DB::table('a_languages')->insert([
			[
            'NAME' => "Portugal",
            'SLUG' => "PT",
            'STATUS' => "1",
        ],[
            'NAME' => "Inglês",
            'SLUG' => "EN",
            'STATUS' => "0",
        ]
	]);
    }
}
